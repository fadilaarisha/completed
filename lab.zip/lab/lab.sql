-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 23 Apr 2020 pada 09.55
-- Versi Server: 10.1.13-MariaDB
-- PHP Version: 7.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lab`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `akun_admin`
--

CREATE TABLE `akun_admin` (
  `id_admin` int(20) NOT NULL,
  `nama_admin` varchar(50) NOT NULL,
  `pass_admin` varchar(50) NOT NULL,
  `status_admin` varchar(20) NOT NULL,
  `update_admin` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `akun_admin`
--

INSERT INTO `akun_admin` (`id_admin`, `nama_admin`, `pass_admin`, `status_admin`, `update_admin`) VALUES
(123456, 'Risa Yudi Wati', 'admin', 'Hadir', '2020-02-03 03:22:27');

-- --------------------------------------------------------

--
-- Struktur dari tabel `akun_peneliti`
--

CREATE TABLE `akun_peneliti` (
  `nama_peneliti` varchar(50) NOT NULL,
  `nim_peneliti` int(20) NOT NULL,
  `jurusan_peneliti` varchar(50) NOT NULL,
  `fakultas_peneliti` varchar(50) NOT NULL,
  `email_peneliti` varchar(50) NOT NULL,
  `pass_peneliti` varchar(50) NOT NULL,
  `nohp_peneliti` int(20) NOT NULL,
  `alamat_peneliti` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `akun_peneliti`
--

INSERT INTO `akun_peneliti` (`nama_peneliti`, `nim_peneliti`, `jurusan_peneliti`, `fakultas_peneliti`, `email_peneliti`, `pass_peneliti`, `nohp_peneliti`, `alamat_peneliti`) VALUES
('jojo', 12, 'tip', 'ftp', 'jojo@yahoo.com', 'jojo', 89898989, 'jl. raya bagong'),
('nana', 321, 'tep', 'ftp', 'nana@yahoo.com', 'nana', 89999999, 'jl. raya mergan'),
('mola', 11111, 'tip', 'ftp', 'mola@yahoo.com', 'mola', 6435678, 'jl. raya singosari'),
('yaya', 12345, 'tip', 'ftp', 'yaya@yahoo.com', 'yaya', 2147483647, 'jl. raya singosari'),
('wiwi', 56789, 'tep', 'ftp', 'wiwi@yahoo.com', 'wiwi', 80989999, 'jl. raya bagong'),
('Joko ', 1351502111, 'biologi', 'fmipa', 'joko@gmail.com', 'peneliti', 852676767, 'Jl. Raya Limau Manis Padang');

-- --------------------------------------------------------

--
-- Struktur dari tabel `alat`
--

CREATE TABLE `alat` (
  `id_alat` int(100) NOT NULL,
  `nama_alat` varchar(100) NOT NULL,
  `jml_alat` int(10) NOT NULL,
  `fungsi_alat` varchar(50) NOT NULL,
  `status_alat` varchar(10) NOT NULL,
  `tgl_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `alat`
--

INSERT INTO `alat` (`id_alat`, `nama_alat`, `jml_alat`, `fungsi_alat`, `status_alat`, `tgl_update`) VALUES
(4, 'Centrifuse', 1, 'Pemisahan', 'Rusak', '2018-01-03 16:15:16'),
(5, 'Coloni Counter', 1, 'Penghitung Koloni', 'Baik', '2018-01-03 16:15:16'),
(6, 'Coloni Counter', 1, 'Penghitung Koloni', 'Baik', '2018-01-03 16:15:16'),
(7, 'Coloni Counter Automatic', 1, 'Penghitung Koloni', 'Baik', '2018-01-03 16:15:16'),
(8, 'Fermentor', 1, 'Fermentasi', 'Rusak', '2018-01-03 16:15:16'),
(9, 'Incubator 1 pintu', 1, 'Untuk Inkubasi', 'Baik', '2018-01-03 16:15:16'),
(10, 'Incubator 2 pintu', 1, 'Untuk Inkubasi', 'Baik', '2018-01-03 16:15:16'),
(11, 'Incubator ', 1, 'Untuk Inkubasi', 'Baik', '2018-01-03 16:15:16'),
(12, 'Hot Plate Stirer', 1, 'Pengadukan-Pemanasan', 'Rusak', '2018-01-03 16:15:16'),
(13, 'Kompor Listrik', 4, 'Pemanaskan', 'Baik', '2018-01-03 16:15:16'),
(14, 'Mikroskop ', 5, 'Pengamatan Mikro', 'Baik', '2018-01-03 16:15:16'),
(15, 'Mikroskop Binokuler', 2, 'Pengamatan Mikro', 'Baik', '2018-01-03 16:15:16'),
(16, 'Mikroskop Binokuler', 2, 'Pengamatan Mikro', 'Baik', '2018-01-03 16:15:16'),
(17, 'Mikroskop Trinokuler', 1, 'Pengamatan Mikro', 'Baik', '2018-01-03 16:15:16'),
(18, 'Stereozoom Mikroskop', 2, 'Pengamatan Mikro', 'Baik', '2018-01-03 16:15:16'),
(19, 'Oven', 1, 'Pemanas', 'Baik', '2018-01-03 16:15:16'),
(20, 'Oven Cabinet', 1, 'Pemanas', 'Baik', '2018-01-03 16:15:16'),
(21, 'Timbangan listrik ', 1, 'Menimbang', 'Rusak', '2018-01-03 16:15:16'),
(22, 'Timbangan digital 4 digit', 1, 'Menimbang', 'Baik', '2018-01-03 16:15:16'),
(23, 'Timbangan digital 2 digit', 1, 'Menimbang', 'Baik', '2018-01-03 16:15:16'),
(24, 'Vortex Mixer', 1, 'Pengaduk', 'Baik', '2018-01-03 16:15:16'),
(25, 'Vortex Velp Scientificia', 2, 'Pengaduk', 'Baik', '2018-01-03 16:15:16'),
(26, 'Water Bath', 1, 'Pemanas', 'Baik', '2018-01-03 16:15:16'),
(27, 'Water Bath ', 1, 'Pemanas', 'Baik', '2018-01-03 16:15:16'),
(28, 'Kulkas 2 pintu', 1, 'Penyimpanan', 'Baik', '2018-01-03 16:15:16'),
(29, 'Kulkas 2 pintu', 1, 'Penyimpanan', 'Baik', '2018-01-03 16:15:16'),
(30, 'Incubator Sekker', 1, 'Inkubasi dan Pengadukan', 'Baik', '2018-01-03 16:15:16'),
(31, 'Mikropipet Fix 200µl', 1, 'Transfer larutan ', 'Baik', '2018-01-03 16:15:16'),
(32, 'Mikropipet Fix 20µl', 1, 'Transfer larutan', 'Baik', '2018-01-03 16:15:16'),
(33, 'Mikropipet 1000-5000µl', 1, 'Transfer larutan', 'Baik', '2018-01-03 16:15:16'),
(34, 'Mikropipet10-100µl', 2, 'Transfer larutan', 'Baik', '2018-01-03 16:15:16'),
(35, 'Mikropipet 100-1000µl', 2, 'Transfer larutan', 'Baik', '2018-01-03 16:15:16'),
(36, 'Dispenser pipet 1- 10 ml', 1, 'Transfer larutan', 'Baik', '2018-01-03 16:15:16'),
(37, 'Lemari Asam portable', 1, 'Tempat Reaksi Zat', 'Baik', '2018-01-03 16:15:16'),
(38, 'Laminar Flow ', 1, 'Ruang Steril', 'Baik', '2018-01-03 16:15:16'),
(39, 'PH meter', 1, 'Pengukur PH ', 'Baik', '2018-01-03 16:15:16'),
(40, 'Stirer Velp scientificia', 1, 'Pengadukan', 'Baik', '2018-01-03 16:15:16'),
(41, 'Heating Magnetic Stirer', 1, 'Pemanasan-Pengadukan', 'Baik', '2018-01-03 16:15:16'),
(42, 'Water Bath ', 1, 'Pemanaskan', 'Baik', '2018-01-03 16:15:16'),
(43, 'UPS', 2, 'Stabilizer listrik', 'Baik', '2018-01-03 16:15:16'),
(44, 'Digital Camera', 1, 'Utk Mikroskop', 'Baik', '2018-01-03 16:15:16'),
(45, 'Heating Magneting Stirer', 1, 'Pemanaskan-Pengadukan', 'Rusak', '2018-01-03 16:15:16'),
(46, 'Mikroskop binokuler', 2, 'Pengamatan Mikro', 'Baik', '2018-01-03 16:15:16'),
(47, 'Mikroskop Binokuler', 1, 'Pengamatan Mikro', 'Baik', '2018-01-03 16:15:16'),
(48, 'Corong besar', 2, 'mengukur takaran', 'Baik', '2018-01-03 16:15:16'),
(49, 'Corong kecil', 2, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(50, 'Eksikator ', 2, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(51, 'Elenmeyer 100/125 ml', 19, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(52, 'Elenmeyer 250 ml', 31, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(53, 'Elenmeyer 500 ml', 11, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(54, 'Elenmeyer 1000 ml', 7, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(55, 'Gelas piala 100 ml', 2, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(56, 'Gelas piala 200 ml', 4, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(57, 'Gelas piala 250 ml', 1, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(58, 'Gelas piala 500 ml', 11, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(59, 'Gelas piala 1000 ml', 7, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(60, 'Gelas piala 2000 ml', 2, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(61, 'Labu ukur 50 ml', 2, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(62, 'Labu ukur 250 ml', 2, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(63, 'Gelas ukur 10 ml', 3, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(64, 'Gelas ukur 25 ml', 4, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(65, 'Gelas ukur 50 ml', 6, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(66, 'Gelas ukur 100 ml', 3, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(67, 'Gelas ukur 250 ml', 1, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(68, 'Gelas ukur 500 ml', 1, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(69, 'Gelas ukur 1000 ml', 1, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(70, 'Jarum ose', 40, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(71, 'Lampu spiritus', 22, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(72, 'Labu semprot', 2, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(73, 'Mortal', 2, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(74, 'Objek glas', 1, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(75, 'Cover glass', 0, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(76, 'Kaca arloji', 2, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(77, 'Batang pengaduk', 3, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(78, 'Pipet takar 1 ml', 52, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(79, 'Pipet takar 2 ml', 52, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(80, 'Pipet takar 5 ml', 12, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(81, 'Pipet takar 10 ml', 17, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(82, 'Pipet tetes plastik', 70, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(83, 'Petridish diameter  9 cm', 347, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(84, 'Petridish diameter 5 cm', 28, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(85, 'Petridish diameter 15 cm', 3, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(86, 'Petridish plastik', 90, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(87, 'Pinset bengkok', 2, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(88, 'Pinset lurus', 4, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(89, 'Rak test tube kayu', 13, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(90, 'Rak test tube stainles', 2, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(91, 'Respirator', 9, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(92, 'Spatula', 2, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(93, 'Tabung reaksi', 164, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(94, 'Tabung reaksi plastic tutup', 75, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(95, 'Tabung reaksi 20 cm', 100, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(96, 'Tabung reaksi pakai tutup', 50, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(97, 'Tabung durham', 100, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(98, 'Termometer ', 4, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(99, 'Sprayer ', 2, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(100, 'Buret automatic plastik', 1, 'alat gelas', 'Baik', '2018-01-03 16:15:16'),
(101, 'Buret automatic gelas', 1, 'alat gelas', 'Baik', '2018-01-03 16:15:16');

-- --------------------------------------------------------

--
-- Struktur dari tabel `bahan`
--

CREATE TABLE `bahan` (
  `id_bahan` varchar(20) NOT NULL,
  `nama_bahan` varchar(100) NOT NULL,
  `stok_bahan` int(20) UNSIGNED NOT NULL,
  `batas_bahan` int(3) UNSIGNED NOT NULL,
  `harga_bahan` int(20) NOT NULL,
  `tgl_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `bahan`
--

INSERT INTO `bahan` (`id_bahan`, `nama_bahan`, `stok_bahan`, `batas_bahan`, `harga_bahan`, `tgl_update`) VALUES
('BHN0001', 'Peptin', 100, 10, 1000, '2020-02-05 17:13:04'),
('BHN0002', 'Agarin 615', 110, 10, 5000, '2020-04-23 07:02:40'),
('BHN0003', 'Alkohol 96 %', 1500, 10, 500, '2020-02-05 12:31:37'),
('BHN0004', 'Asam asetat', 300, 10, 2000, '2020-02-05 12:31:46'),
('BHN0005', 'Bacto agar', 500, 10, 5000, '2020-02-05 12:31:51'),
('BHN0006', 'BD Difco mil medium', 500, 10, 5000, '2020-02-05 12:31:59'),
('BHN0007', 'Beef extract', 2, 10, 5000, '2020-02-05 12:32:04'),
('BHN0008', 'BGLBB', 500, 10, 5000, '2020-02-05 12:32:11'),
('BHN0009', 'Brain heart infusion broth', 500, 10, 5000, '2020-02-05 12:32:17'),
('BHN0010', 'Brilian Green / Brilla broth', 674, 10, 5000, '2020-02-05 12:32:25'),
('BHN0011', 'Buffer PH 4', 300, 10, 2000, '2020-02-05 12:32:31'),
('BHN0012', 'Buffer PH 7', 400, 10, 2000, '2020-02-05 12:32:36'),
('BHN0013', 'D glukosa anhidros', 1000, 10, 3000, '2020-02-05 12:32:41'),
('BHN0014', 'D glukosa mono hidrat', 82, 10, 2000, '2020-02-05 12:32:47'),
('BHN0015', 'Eosin methilen blue agar', 500, 10, 5000, '2020-02-05 12:32:51'),
('BHN0016', 'Formalin', 4000, 10, 1000, '2020-02-05 12:32:55'),
('BHN0017', 'Gelatin', 1000, 10, 2000, '2020-02-05 12:32:59'),
('BHN0018', 'Hexadecyl trimethyl N4Br', 100, 10, 10000, '2020-02-05 12:33:06'),
('BHN0019', 'Iodium solution', 740, 10, 3000, '2020-02-05 12:33:11'),
('BHN0020', 'KH2PO4', 1806, 10, 2000, '2020-02-05 12:33:17'),
('BHN0021', 'Lactose broth', 209, 10, 5000, '2020-02-05 12:33:22'),
('BHN0022', 'Lugol lusong', 550, 10, 2000, '2020-02-05 12:33:27'),
('BHN0023', 'Malt ekstrak', 500, 10, 5000, '2020-02-05 12:33:32'),
('BHN0024', 'MgSO4 7 H2O', 100, 10, 1000, '2020-02-05 12:33:37'),
('BHN0025', 'MRS agar', 361, 10, 5000, '2020-02-05 12:33:44'),
('BHN0026', 'MRS broth', 500, 10, 5000, '2020-02-05 12:34:05'),
('BHN0027', 'Natrium klorida', 882, 10, 2000, '2020-02-05 12:34:09'),
('BHN0028', 'Natrium klorida teknis', 857, 10, 1000, '2020-02-05 12:34:13'),
('BHN0029', 'Natrium sulfit', 800, 10, 3000, '2020-02-05 12:34:17'),
('BHN0030', 'Nutrient agar', 1076, 10, 5000, '2020-02-05 12:34:24'),
('BHN0031', 'Oil imersi', 460, 10, 2000, '2020-02-05 12:34:29'),
('BHN0032', 'Pepton', 963, 10, 5000, '2020-02-05 12:34:34'),
('BHN0033', 'Plate count agar / PCA', 403, 10, 5000, '2020-02-05 12:34:38'),
('BHN0034', 'Potato dextrose agar/PDA', 107, 10, 5000, '2020-02-05 12:34:45'),
('BHN0035', 'Potato dextrose broth/ PDB', 1000, 10, 5000, '2020-02-05 12:34:49'),
('BHN0036', 'Sabouraud Dextrose Broth', 500, 10, 5000, '2020-02-05 12:34:53'),
('BHN0037', 'Safranin', 19, 10, 200000, '2020-02-05 12:34:59'),
('BHN0038', 'Salmonella sigella agar/SSA', 394, 10, 5000, '2020-02-05 12:35:03'),
('BHN0039', 'Skim milk powder', 570, 10, 3000, '2020-02-05 12:35:08'),
('BHN0040', 'Soluble strach', 99, 10, 5000, '2020-02-05 12:35:13'),
('BHN0041', 'Standar method agar', 1000, 10, 3000, '2020-02-05 12:35:25'),
('BHN0042', 'Triptone', 500, 10, 3000, '2020-02-05 12:35:30'),
('BHN0043', 'Twin 80', 195, 10, 3000, '2020-02-05 12:35:37'),
('BHN0044', 'Borax', 100, 0, 6000, '2020-02-05 12:45:45');

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_penelitian`
--

CREATE TABLE `data_penelitian` (
  `id_proposal` varchar(100) NOT NULL,
  `id_peneliti` int(20) NOT NULL,
  `judul_penelitian` varchar(200) NOT NULL,
  `mulai_penelitian` date NOT NULL,
  `akhir_penelitian` date NOT NULL,
  `dosen1_penelitian` varchar(200) NOT NULL,
  `dosen2_penelitian` varchar(200) NOT NULL,
  `parameter_penelitian` varchar(200) NOT NULL,
  `status_penelitian` varchar(20) NOT NULL DEFAULT 'Menunggu Konfirmasi',
  `catatan_penelitian` varchar(2000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `data_penelitian`
--

INSERT INTO `data_penelitian` (`id_proposal`, `id_peneliti`, `judul_penelitian`, `mulai_penelitian`, `akhir_penelitian`, `dosen1_penelitian`, `dosen2_penelitian`, `parameter_penelitian`, `status_penelitian`, `catatan_penelitian`) VALUES
('DP0004', 12, 'Penelitian Dasar', '2019-03-22', '2019-03-22', 'Prof. A', 'Prof. B', 'Uji antimikroba', 'Menunggu Konfirmasi', NULL),
('DP0002', 12, 'Pengujian Entitas Jamur', '2018-11-16', '2018-11-16', 'Prof. A', 'Prof. B', 'Menentukan angka lempeng total mikroba', 'Aktif', '-'),
('DP0003', 12, 'Pengujian Entitas Jamur 2', '2019-01-04', '2019-01-04', 'Prof. A', 'Prof. B', 'Menentukan angka lempeng total mikroba', 'Menunggu Konfirmasi', '-');

-- --------------------------------------------------------

--
-- Struktur dari tabel `info`
--

CREATE TABLE `info` (
  `id_info` int(200) NOT NULL,
  `judul_info` varchar(200) NOT NULL,
  `konten_info` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `info`
--

INSERT INTO `info` (`id_info`, `judul_info`, `konten_info`) VALUES
(1, 'FAQ Pengujung', 'FAQ Pengunjung'),
(2, 'FAQ Peneliti', 'FAQ Peneliti'),
(3, 'Profil Lab', 'Profil lab');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jadwal`
--

CREATE TABLE `jadwal` (
  `id_keg` int(100) NOT NULL,
  `nama_keg` varchar(100) NOT NULL,
  `hari_keg` varchar(10) NOT NULL,
  `jam_awal_keg` time NOT NULL,
  `jam_akhir_keg` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `jadwal`
--

INSERT INTO `jadwal` (`id_keg`, `nama_keg`, `hari_keg`, `jam_awal_keg`, `jam_akhir_keg`) VALUES
(1, 'Praktikum Uji Bakteri 1', 'Senin', '12:30:00', '15:45:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jadwal_penelitian`
--

CREATE TABLE `jadwal_penelitian` (
  `id_jadwal` int(10) UNSIGNED NOT NULL,
  `judul_penelitian` varchar(200) NOT NULL,
  `id_peneliti` int(20) NOT NULL,
  `tgl_penelitian` date NOT NULL,
  `jam_mulai` time NOT NULL,
  `jam_selesai` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data untuk tabel `jadwal_penelitian`
--

INSERT INTO `jadwal_penelitian` (`id_jadwal`, `judul_penelitian`, `id_peneliti`, `tgl_penelitian`, `jam_mulai`, `jam_selesai`) VALUES
(19, 'Pengujian Entitas Jamur', 12, '2019-03-22', '01:51:00', '01:59:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` int(11) NOT NULL,
  `tgl_transaksi` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `nama_transaksi` varchar(50) NOT NULL,
  `jenis_transaksi` varchar(20) NOT NULL,
  `id_bahan` varchar(20) NOT NULL,
  `jumlah_transaksi` float NOT NULL,
  `harga_transaksi` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `tgl_transaksi`, `nama_transaksi`, `jenis_transaksi`, `id_bahan`, `jumlah_transaksi`, `harga_transaksi`) VALUES
(1, '2020-04-23 07:02:40', 'Pranata', 'Pembelian', 'BHN0002', 10, 50000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `akun_admin`
--
ALTER TABLE `akun_admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `akun_peneliti`
--
ALTER TABLE `akun_peneliti`
  ADD PRIMARY KEY (`nim_peneliti`),
  ADD UNIQUE KEY `nama_peneliti_2` (`nama_peneliti`),
  ADD KEY `nama_peneliti` (`nama_peneliti`),
  ADD KEY `nama_peneliti_3` (`nama_peneliti`);

--
-- Indexes for table `alat`
--
ALTER TABLE `alat`
  ADD PRIMARY KEY (`id_alat`);

--
-- Indexes for table `bahan`
--
ALTER TABLE `bahan`
  ADD PRIMARY KEY (`id_bahan`);

--
-- Indexes for table `data_penelitian`
--
ALTER TABLE `data_penelitian`
  ADD PRIMARY KEY (`judul_penelitian`),
  ADD KEY `id_peneliti` (`id_peneliti`);

--
-- Indexes for table `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`id_info`);

--
-- Indexes for table `jadwal`
--
ALTER TABLE `jadwal`
  ADD PRIMARY KEY (`id_keg`);

--
-- Indexes for table `jadwal_penelitian`
--
ALTER TABLE `jadwal_penelitian`
  ADD PRIMARY KEY (`id_jadwal`),
  ADD KEY `judul_penelitian` (`judul_penelitian`),
  ADD KEY `id_peneliti` (`id_peneliti`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`),
  ADD KEY `id_bahan` (`id_bahan`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `akun_admin`
--
ALTER TABLE `akun_admin`
  MODIFY `id_admin` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=123457;
--
-- AUTO_INCREMENT for table `alat`
--
ALTER TABLE `alat`
  MODIFY `id_alat` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;
--
-- AUTO_INCREMENT for table `info`
--
ALTER TABLE `info`
  MODIFY `id_info` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `jadwal`
--
ALTER TABLE `jadwal`
  MODIFY `id_keg` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `jadwal_penelitian`
--
ALTER TABLE `jadwal_penelitian`
  MODIFY `id_jadwal` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `data_penelitian`
--
ALTER TABLE `data_penelitian`
  ADD CONSTRAINT `data_penelitian_ibfk_1` FOREIGN KEY (`id_peneliti`) REFERENCES `akun_peneliti` (`nim_peneliti`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `jadwal_penelitian`
--
ALTER TABLE `jadwal_penelitian`
  ADD CONSTRAINT `jadwal_penelitian_ibfk_1` FOREIGN KEY (`judul_penelitian`) REFERENCES `data_penelitian` (`judul_penelitian`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `jadwal_penelitian_ibfk_2` FOREIGN KEY (`id_peneliti`) REFERENCES `akun_peneliti` (`nim_peneliti`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`id_bahan`) REFERENCES `bahan` (`id_bahan`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
