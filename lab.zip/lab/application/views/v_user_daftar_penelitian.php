<?php $this->load->view('header-akun');?>
<?php $this->load->view('sidebar-user');?>

<div id="content">
<div class="container">
<div class="row">
    <div class="col-md-1"></div>
    <div class="col-lg-11">
        <div class="ibox float-e-margins">
            <div class="ibox-content">
                <div class="table-responsive">
					
					<a data-toggle="modal" class="btn btn-xs btn-info" href="#modal-add"><i class="fa fa-paste"></i> Tambah Penelitian</a>
					
                    <table class="table table-hover">
                        <thead>
                        <tr>
                            <th>No</th>
							<th>Mulai</th>
							<th>Berakhir</th>
							<th>Judul Penelitian</th>
							<th>Dosen 1</th>
							<th>Dosen 2</th>
							<th>Parameter Penelitian</th>
							<th>Status</th>
							<th>Catatan</th>	
                        </tr>
                        </thead>
                        <tbody>
                        <?php 
						$no=1;
						foreach($peneliti_penelitian->result() as $aa){ 
						?>							
						<tr>
						<td><?php echo $no++?></td>
						<td><?=$aa->mulai_penelitian;?></td> 
						<td><?=$aa->akhir_penelitian;?></td> 
						<td><?=$aa->judul_penelitian;?></td> 
						<td><?=$aa->dosen1_penelitian;?></td>
						<td><?=$aa->dosen2_penelitian;?></td>
						<td><?=$aa->parameter_penelitian;?></td>
						<td><?=$aa->status_penelitian;?></td>
						<td><?=$aa->catatan_penelitian;?></td>
						<td>
							<?php if ($aa->status_penelitian == "Menunggu Konfirmasi") {?>
                                <a href="<?php echo site_url('C_daftar_penelitian/hapus/'.$aa->id_proposal)?>" class="btn btn-xs btn-danger" type="button"><i class="fa fa-times"></i>Delete</a>
							<?php } ?>
                       </td>
					</tr>
					<?php 
                        }
                        ?>
                        </tbody>
                    </table>
					
					<div id="modal-add" class="modal fade" aria-hidden="true">
                                <div class="modal-dialog" style="width: 500px">
                                    <div class="modal-content">
                                        <div class="modal-body">
                                            <div class="row">
                                                <h3 class="m-t-none m-b">Tambah</h3>
                                                    <form role="form" action="<?php echo site_url('C_daftar_penelitian/add/')?>" method="POST">
                                                     <div class="form-group"><label>Judul Penelitian</label> <input type="text" name="judul_penelitian_add" class="form-control" required=""></div>
													 
<div class="form-group"><label>Tanggal</label>
<div class= "input-daterange input-group"> <input type="date" name="tanggal_mulai_add" class="form-control-sm form-control" required=""> <span class="input-group-addon">to</span> <input type="date" name="tanggal_selesai_add" class="form-control-sm form-control" required="" ></div></div>

													<div class="form-group"><label>Dosen 1</label> <input type="text" name="dosen1_add" class="form-control" required=""></div>
													<div class="form-group"><label>Dosen 2</label> <input type="text" name="dosen2_add" class="form-control" required=""></div>
													<!-- <div class="custom-file"><label>Proposal</label> <input type="file" name="proposal_daftar" class="custom-file-input"></div> -->
													<div class="form-group"><label>Parameter Penelitian</label>
														<select class="form-control" name= "parameter_add" required="">
														<option>Menentukan angka lempeng total mikroba</option>
														<option>Menentukan angka lempeng total jamur dan kapang</option>
														<option>Menentukan angka lempeng total Bakteri Asam Laktat</option>
														<option>Uji antimikroba</option>
														</select>
													</div>
													<button class="btn btn-sm btn-primary pull-right m-t-n-xs" type="submit"><strong>Simpan</strong></button>
													</div>   
													</form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                </div>

            </div>
        </div>
    </div>
	<script type="text/javascript" src="https://cdn.jsdelivr.net/jquery/latest/jquery.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
</div>
