<?php $this->load->view('header-akun');?>
<?php $this->load->view('sidebar-user');?>

<div id="content">
<div class="container">
<div class="row">
    <div class="col-md-1"></div>
    <div class="col-lg-11">
        <div class="ibox float-e-margins">
            <div class="ibox-content">
			<h1> Profil Akun </h1> </br>
			<?php 
				foreach($akun_peneliti->result() as $aa){ ?>	
			<p class="text-left"><label class="col-sm-2 col-form-label">Nama</label><?php echo $aa->nama_peneliti;?></p>
			<p class="text-left"><label class="col-sm-2 col-form-label">Nim</label><?php echo $aa->nim_peneliti;?></p>
			<p class="text-left"><label class="col-sm-2 col-form-label">Fakultas</label><?php echo $aa->fakultas_peneliti;?></p>
			<p class="text-left"><label class="col-sm-2 col-form-label">Jurusan</label><?php echo $aa->jurusan_peneliti;?></p>
			<p class="text-left"><label class="col-sm-2 col-form-label">Email</label><?php echo $aa->email_peneliti;?></p>
			<p class="text-left"><label class="col-sm-2 col-form-label">No. HP</label><?php echo $aa->nohp_peneliti;?></p>
			<p class="text-left"><label class="col-sm-2 col-form-label">Alamat</label><?php echo $aa->alamat_peneliti;?></p>
			
			<form class="m-t" role="form" action="<?php echo site_url('C_user_pengaturan/edit')?>" method="post" >
									<div class="form-group">
                                    <label>Password Lama</label>
                                    <input type="password" class="form-control" name="pass_lama"required="">
                                </div>
                                <div class="form-group">
                                    <label>Password Baru</label>
                                    <input type="password" class="form-control" name="pass_baru"required="">
                                </div>
                                <div class="text-center">
                                    <button type="submit" class="btn btn-template-main"><i class="fa fa-sign-in"></i> Simpan</button>
                                </div>
						
                            </form>
			<?php } ?>
			</div>
		</div>
	</div>
</div>
</div>
</div>