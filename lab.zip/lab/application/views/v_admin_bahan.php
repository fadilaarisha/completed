<?php $this->load->view('header-akun');?>
<?php $this->load->view('sidebar-admin');?>

<div class="container">
<div class="row">
<div class="col-md-1"></div>
    <div class="col-lg-10">
        <div class="ibox float-e-margins">
            <div class="ibox-content">
				<form action="<?php echo site_url('C_bahan/cari')?>" method="POST">
					<div class="col-lg-11"><input type="text" name= "cari_add"placeholder="Cari" class="form-control">
					</div>
					<div class="form-group row">
					<button class="btn btn-sm btn-info" type="submit">Cari</button>
					</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<div class="container">
<div class="row">
<div class="col-md-1"></div>
    <div class="col-lg-10">
        <div class="ibox float-e-margins">
            <div class="ibox-content">
                <div class="table-responsive">
					
					<a data-toggle="modal" class="btn btn-xs btn-info" href="#modal-add"><i class="fa fa-paste"></i> Tambah Bahan</a>
					
					<a href="<?php echo site_url('C_bahan/download')?>" class="btn btn-xs btn-danger" type="button" target="_blank">Download</a>
					 
					 <br></br>
                    <table class="table table-hover">
                        <thead>
                        <tr>
                            <th>No</th>
							<th>Tanggal Update</th>
							<th>Nama</th>
							<th>Stok</th>
							<th>Harga</th>
						
                        </tr>
                        </thead>
                        <tbody>
                        <?php 
						$no=1;
						foreach($admin_bahan->result() as $aa){ 
						?>							
						<tr>
						<td><?php echo $no++?></td>
						<td><?=$aa->tgl_update;?></td> 
						<td><?=$aa->nama_bahan;?></td> 
						<td><?=$aa->stok_bahan;?></td> 
						<td><?=$aa->harga_bahan;?></td>		
						<td>
                                <a data-toggle="modal" class="btn btn-xs btn-info" href="#modal-edit<?php echo $aa->id_bahan;?>"><i class="fa fa-paste"></i> Edit</a>
                                
                                <a href="<?php echo site_url('C_bahan/hapus/'.$aa->id_bahan)?>" class="btn btn-xs btn-danger" type="button"><i class="fa fa-times"></i>Delete</a>
                            </td>
                            <div id="modal-edit<?php echo $aa->id_bahan;?>" class="modal fade" aria-hidden="true">
                                <div class="modal-dialog" style="width: 300px">
                                    <div class="modal-content">
                                        <div class="modal-body">
                                            <div class="row">
                                                <h3 class="m-t-none m-b">Edit data</h3>
                                                    <form role="form" action="<?php echo site_url('C_bahan/edit/'.$aa->id_bahan)?>" method="post">
                                                        <div class="form-group"><label>Nama Bahan</label> <input type="text" name="nama_bahan_edit" value="<?php echo $aa->nama_bahan;?>" class="form-control"></div>
														<div class="form-group"><label>Stok Bahan</label> <input type="number" name="stok_bahan_edit" value="<?php echo $aa->stok_bahan;?>" class="form-control"></div>
														<div class="form-group"><label>Harga Bahan</label> <input type="text" name="harga_bahan_edit" value="<?php echo $aa->harga_bahan;?>" class="form-control"></div>
                                                            <button class="btn btn-sm btn-primary pull-right m-t-n-xs" type="submit"><strong>Simpan</strong></button>
                                                        </div>
                                                    </form>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </tr>
                        <?php 
                        }
                        ?>
                        </tbody>
                    </table>
					
					<div id="modal-add" class="modal fade" aria-hidden="true">
                                <div class="modal-dialog" style="width: 300px">
                                    <div class="modal-content">
                                        <div class="modal-body">
                                            <div class="row">
                                                <h3 class="m-t-none m-b">Tambah Data</h3>
                                                    <form role="form" action="<?php echo site_url('C_bahan/add/')?>" method="post">
                                                        <div class="form-group"><label>Nama Bahan</label> <input type="text" name="nama_bahan_add" class="form-control"></div>
														<div class="form-group"><label>Stok Bahan</label> <input type="number" name="stok_bahan_add" class="form-control"></div>
														<div class="form-group"><label>Harga Bahan</label> <input type="number" name="harga_bahan_add" class="form-control"></div>
													
													<button class="btn btn-sm btn-primary pull-right m-t-n-xs" type="submit"><strong>Simpan</strong></button>
                                                        </div>
                                                    </form>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                </div>

            </div>
        </div>
    </div>
	</div>
	</div>