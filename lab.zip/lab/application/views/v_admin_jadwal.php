<?php $this->load->view('header-akun');?>
<?php $this->load->view('sidebar-admin');?>

<div id="content">
<div class="container">
<div class="row">
    <div class="col-md-1"></div>
    <div class="col-lg-10">
        <div class="ibox float-e-margins">
            <div class="ibox-content">
                <div class="table-responsive">
					
					<a data-toggle="modal" class="btn btn-xs btn-info" href="#modal-add"><i class="fa fa-paste"></i> Tambah Jadwal</a>
					
                    <table class="table table-hover">
                        <thead>
                        <tr>
                            <th>No</th>
							<th>Nama Kegiatan</th>
							<th>Hari</th>
							<th>Jam Awal</th>
							<th>Jam Akhir</th>
							
                        </tr>
                        </thead>
                        <tbody>
                        <?php 
						$no=1;
						foreach($admin_jadwal->result() as $aa){ 
						?>							
						<tr>
						<td><?php echo $no++?></td>
						<td><?=$aa->nama_keg;?></td> 
						<td><?=$aa->hari_keg;?></td> 
						<td><?=$aa->jam_awal_keg;?></td>
						<td><?=$aa->jam_akhir_keg;?></td> 
						<td>
                                <a data-toggle="modal" class="btn btn-xs btn-info" href="#modal-edit<?php echo $aa->id_keg;?>"><i class="fa fa-paste"></i> Edit</a>
                                
                                <a href="<?php echo site_url('C_jadwal/hapus/'.$aa->id_keg)?>" class="btn btn-xs btn-danger" type="button"><i class="fa fa-times"></i>Delete</a>
                            </td>
                            <div id="modal-edit<?php echo $aa->id_keg;?>" class="modal fade" aria-hidden="true">
                                <div class="modal-dialog" style="width: 300px">
                                    <div class="modal-content">
                                        <div class="modal-body">
                                            <div class="row">
                                                <h3 class="m-t-none m-b">Edit data</h3>
                                                    <form role="form" action="<?php echo site_url('C_jadwal/edit/'.$aa->id_keg)?>" method="post">
                                                        <div class="form-group"><label>Nama Kegiatan</label> <input type="text" name="nama_keg_edit" value="<?php echo $aa->nama_keg;?>" class="form-control"></div>
														<div class="form-group"><label>Hari</label>
														<select class="form-control" name= "hari_keg_edit" value="<?php echo $aa->hari_keg;?>" required="">
														<option>Senin</option>
														<option>Selasa</option>
														<option>Rabu</option>
														<option>Kamis</option>
														<option>Jumat</option>
														<option>Sabtu</option>
														<option>Minggu</option>
														</select>
														</div>
														<div class="form-group"><label>Jam Awal</label> <input type="time" name="jam_awal_keg_edit" value="<?php echo $aa->jam_awal_keg;?>" class="form-control"></div>
														<div class="form-group"><label>Jam Akhir</label> <input type="time" name="jam_akhir_keg_edit" value="<?php echo $aa->jam_akhir_keg;?>" class="form-control"></div>
                                                            <button class="btn btn-sm btn-primary pull-right m-t-n-xs" type="submit"><strong>Simpan</strong></button>
                                                        </div>
                                                    </form>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </tr>
                        <?php 
                        }
                        ?>
                        </tbody>
                    </table>
					
					<div id="modal-add" class="modal fade" aria-hidden="true">
                                <div class="modal-dialog" style="width: 300px">
                                    <div class="modal-content">
                                        <div class="modal-body">
                                            <div class="row">
                                                <h3 class="m-t-none m-b">Tambah Data</h3>
                                                    <form role="form" action="<?php echo site_url('C_jadwal/add/')?>" method="post">
                                                        <div class="form-group"><label>Nama Kegiatan</label> <input type="text" name="nama_keg_add" class="form-control"></div>
														<div class="form-group"><label for="hari_keg_add">Hari</label>
														<select class="form-control" name= "hari_keg_add" required="">
														<option>Senin</option>
														<option>Selasa</option>
														<option>Rabu</option>
														<option>Kamis</option>
														<option>Jumat</option>
														<option>Sabtu</option>
														<option>Minggu</option>
														</select></div>
														<div class="form-group"><label>Jam Awal</label> <input type="time" name="jam_awal_keg_add" class="form-control"></div>
														<div class="form-group"><label>Jam Akhir</label> <input type="time" name="jam_akhir_keg_add" class="form-control"></div>
                                                            <button class="btn btn-sm btn-primary pull-right m-t-n-xs" type="submit"><strong>Simpan</strong></button>
                                                        </div>
                                                    </form>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                </div>

            </div>
        </div>
    </div>
	</div>