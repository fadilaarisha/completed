<?php $this->load->view('header');?>

<div id="content">
            <div class="container">


                <div class="row">

                    <!-- *** LEFT COLUMN ***
			 _________________________________________________________ -->

                    <div class="col-md-9" id="customer-orders">
						<?php 
						foreach($faq_pengunjung->result() as $a){
							?>		
						
						<h1><?php echo $a->judul_info;?> </h1>
						
                        <p class="text-muted lead"><?php echo $a->konten_info;?></p>
	<?php } ?>						
                            </div>
                            <!-- /.table-responsive -->

                        </div>
                        <!-- /.box -->

                    </div>
				</div>
			</div>
		</div>
		
	
	</div>

	<?php $this->load->view('footer');?>