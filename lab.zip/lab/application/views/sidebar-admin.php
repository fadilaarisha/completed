<nav class="navbar-default navbar-static-side" role="navigation">
    <div class="container-fluid">
        <ul class="nav" id="side-menu">
			<li class="nav-header">
                <div class="dropdown profile-element"> 
                    <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                        <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold"><?php echo $this->session->userdata('nama');?></strong>
                         </span> <span class="text-muted text-xs block"><?php echo $this->session->userdata('divisi');?> <b class="caret"></b></span> </span> </a>
                </div>
			    <div class="logo-element">
                    IN+
                </div>
            </li>
            
            <li>
                <a href="<?php echo site_url('C_admin/home')?>"><i class="fa fa-home"></i> <span class="nav-label">Home</span></a>
            </li>
            <li>
                <a href="<?php echo site_url('C_admin/bahan')?>"><i class="fa fa-database"></i> <span class="nav-label">Bahan Laboratorium</span></a>
            </li>
			<li>
                <a href="<?php echo site_url('C_admin/alat')?>"><i class="fa fa-database"></i> <span class="nav-label">Alat Laboratorium</span></a>
            </li>
			<li>
                <a href="<?php echo site_url('C_admin/transaksi')?>"><i class="fa fa-database"></i> <span class="nav-label">Transaksi</span></a>
            </li>
			<li>
                <a href=""><i class="fa fa-pencil"></i> <span class="nav-label">Penelitian</span></a>
				<ul class="nav nav-second-level">
                             <li>
                                    <a href="<?php echo site_url('C_admin/daftar_penelitian')?>">Daftar Penelitian</a>
                                </li>
								<li>
                                    <a href="<?php echo site_url('C_admin/akun_peneliti')?>">Akun Peneliti</a>
                                </li>
								<li>
                                    <a href="<?php echo site_url('C_admin/jadwal_penelitian')?>">Jadwal Penelitian</a>
                                </li>
                            </ul>
            </li>			
			<li>
                <a href="<?php echo site_url('C_admin/jadwal')?>"><i class="fa fa-database"></i> <span class="nav-label">Jadwal Praktikum</span></a>
            </li>
			
			 <li>
				<a href="<?php echo site_url('C_admin/faq_pengunjung')?>"><i class="fa fa-database"></i> <span class="nav-label">FAQ Pengunjung</span></a>
			</li>

			<li>
				<a href="<?php echo site_url('C_admin/faq_peneliti')?>"><i class="fa fa-database"></i> <span class="nav-label">FAQ Peneliti</span></a>
			</li>

			<li>
				<a href="<?php echo site_url('C_admin/profil_lab')?>"><i class="fa fa-database"></i> <span class="nav-label">Profil Laboratorium</span></a>
			</li>

            
			<li>
                <a href="<?php echo site_url('C_admin/pengaturan')?>"><i class="fa fa-database"></i> <span class="nav-label">Pengaturan Akun</span></a>
            </li>
        </ul>
    </div>
</nav>
