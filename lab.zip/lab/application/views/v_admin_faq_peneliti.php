<?php $this->load->view('header-akun');?>
<?php $this->load->view('sidebar-admin');?>

<div id="content">
<div class="container">
<div class="row">
    <div class="col-md-1"></div>
    <div class="col-lg-10">
        <div class="ibox float-e-margins">
            <div class="ibox-content">
                <div class="ibox-content text-center p-md">
								
					<?php 
						foreach($admin_faq_peneliti->result() as $aa){
					?>
                  
					<form class="m-t" role="form" action="<?php echo site_url('C_informasi/edit')?>" method="post" >
									<div class="form-group">
                                    <label>Judul</label>
                                    <input type="text" class="form-control" name="judul_edit" value="<?php echo $aa->judul_info;?>" required="">
                                </div>
                                <div class="form-group">
								<label>Konten Info</label>
								<textarea class="form-control" rows="5"  name="konten_edit" required=""><?php echo $aa->konten_info;?></textarea>
                                </div>
                                <div class="text-center">
                                    <button type="submit" class="btn btn-template-main"><i class="fa fa-sign-in"></i> Simpan</button>
                                </div>
						
                            </form>
						<?php } ?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

			