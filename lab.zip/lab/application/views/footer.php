<footer id="footer">
            <div class="container">
                <div class="col-md-3 col-sm-6">
                    <h4>About us</h4>

                    <p>Laboratorium Mikrobiologi dan Bioteknologi Hasil Pertanian Fakultas Teknologi Pertanian melayani praktikum dan penelitian mengenai uji mikrobiologi hasil pertanian.</p>

                    <hr>

                    
                    <hr class="hidden-md hidden-lg hidden-sm">

                </div>
                <div class="col-md-3 col-sm-6">

                    <h4>Contact</h4>

                    <p><strong>Gedung Labor Teknologi Pertanian</strong>
                        <br>Fakultas Teknologi Pertanian
                        <br>Kampus Unand Limau Manis, Padang
                        <br>Kode Pos 25163
                    </p>

                    
                    <hr class="hidden-md hidden-lg hidden-sm">

                </div>
                <!-- /.col-md-3 -->



                
                <!-- /.col-md-3 -->
            </div>
            <!-- /.container -->
        </footer>
        <!-- /#footer -->

        <!-- *** FOOTER END *** -->
