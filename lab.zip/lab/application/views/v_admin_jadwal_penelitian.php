<?php $this->load->view('header-akun');?>
<?php $this->load->view('sidebar-admin');?>

<body>
<div id="content">
<div class="container">
<div class="row">
    <div class="col-md-1"></div>
    <div class="col-lg-10">
        <div class="ibox float-e-margins">
            <div class="ibox-content">
                <div class="table-responsive">
					
					<a data-toggle="modal" class="btn btn-xs btn-info" href="#modal-add"><i class="fa fa-paste"></i> Tambah Jadwal</a>
					
                    <table class="table table-hover">
                        <thead>
                        <tr>
                            <th>No </th>
							<th>Tanggal</th>
							<th>Waktu Mulai</th>
							<th>Waktu Selesai</th>
							<th>Nama Lengkap</th>	
							<th>NIM</th>	
							<th>Judul Penelitian</th>	
                        </tr>
                        </thead>
                        <tbody>
                        <?php 
						$no=1;
						foreach($admin_jadwal_penelitian->result() as $aa){ 
						?>							
						<tr>
						<td><?php echo $no++?></td>
						<td><?=$aa->tgl_penelitian;?></td> 
						<td><?=$aa->jam_mulai;?></td> 
						<td><?=$aa->jam_selesai;?></td> 
						<td><?=$aa->nama_peneliti;?></td> 
						<td><?=$aa->nim_peneliti;?></td> 
						<td><?=$aa->judul_penelitian;?></td>
						<td>
                                <a data-toggle="modal" class="btn btn-xs btn-info" href="#modal-edit<?php echo $aa->id_jadwal;?>"><i class="fa fa-paste"></i> Edit</a>
								<a href="<?php echo site_url('C_jadwal_peneliti/hapus/'.$aa->id_jadwal)?>" class="btn btn-xs btn-danger" type="button"><i class="fa fa-times"></i>Delete</a>
                       </td>
					   
					    <div id="modal-edit<?php echo $aa->id_jadwal;?>" class="modal fade" aria-hidden="true">
                                <div class="modal-dialog" style="width: 300px">
                                    <div class="modal-content">
                                        <div class="modal-body">
                                            <div class="row">
                                                <h3 class="m-t-none m-b">Edit data</h3>
                                                    <form role="form" action="<?php echo site_url('C_jadwal_peneliti/edit/'.$aa->id_jadwal)?>" method="post">
                                                        <div class="form-group"><label>NIM</label> <input type="number" min="0" name="nim_edit" value="<?php echo $aa->nim_peneliti;?>" class="form-control" required=""></div>
														<div class="form-group"><label>Judul Penelitian</label> <input type="text" name="judul_peneliti_edit" value="<?php echo $aa->judul_penelitian;?>" class="form-control" required=""></div>
														<div class="form-group"><label>Tanggal</label> <input type="date" name="tanggal_peneliti_edit" value="<?php echo $aa->tgl_penelitian;?>" class="form-control" required=""></div>
														<div class="form-group"><label>Jam Mulai</label> <input type="time" name="jam_mulai_edit" value="<?php echo $aa->mulai_penelitian;?>" class="form-control" required=""></div>
														<div class="form-group"><label>Jam Selesai</label> <input type="time" name="jam_selesai_edit" value="<?php echo $aa->akhir_penelitian;?>" class="form-control" required="">
														<button class="btn btn-sm btn-primary pull-right m-t-n-xs" type="submit"><strong>Simpan</strong></button>
                                                        </div>														
                                                    </form>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>        
					   
					</tr>
					<?php 
                        }
                        ?>
                        </tbody>
                    </table>
					
					<div id="modal-add" class="modal fade" aria-hidden="true">
                                <div class="modal-dialog" style="width: 300px">
                                    <div class="modal-content">
                                        <div class="modal-body">
                                            <div class="row">
                                                <h3 class="m-t-none m-b">Tambah Jadwal</h3>
                                                    <form role="form" action="<?php echo site_url('C_jadwal_peneliti/add/')?>" method="POST">
														<div class="form-group"><label>NIM</label> <input type="number" min="0" name="nim_add" class="form-control" required=""></div>
														<div class="form-group"><label>Judul Penelitian</label> <input type="text" name="judul_peneliti_add" class="form-control" required=""></div>
														<div class="form-group"><label>Tanggal</label> <input type="date" name="tanggal_peneliti_add" class="form-control" required=""></div>
														<div class="form-group"><label>Jam Mulai</label> <input type="time" name="jam_mulai_add" class="form-control" required=""></div>
														<div class="form-group"><label>Jam Selesai</label> <input type="time" name="jam_selesai_add" class="form-control" required=""></div>
														<button class="btn btn-sm btn-primary pull-right m-t-n-xs" type="submit"><strong>Simpan</strong></button>
												   <!-- <div class="custom-file"><label>Proposal</label> <input type="file" name="proposal_daftar" class="custom-file-input"></div> -->
													</div>   
													</form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            
							</div>
                </div>

            </div>
        </div>
    </div>
</div>
    <script src="<?php echo base_url('assets/js/bootstrap-datepicker.js') ?>"></script>
	<script src="<?php echo base_url()?>'assets/js/jquery-3.1.1.min.js"></script>
		<script src="<?php echo base_url()?>assets/js/footable.all.min.js"></script>
</body>