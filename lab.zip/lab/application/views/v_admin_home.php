<?php $this->load->view('header-akun');?>
<?php $this->load->view('sidebar-admin');?>

<div id="content">
	<div class="col-md-3"></div>
	<div class="col-md-8">
	</br>
		<div class="jumbotron jumbotron-fluid">
  			<div class="container">
    			<h1 class="display-3">Selamat Datang!</h1>
    			<p class="lead">Ini merupakan halaman admin Sistem Pengelolaan Laboratorium Fakultas Teknologi Pertanian Universitas Andalas Padang</p>
  			</div>
		</div>
	</div>
</div>

<div class="row">
	<div class="col-md-3"></div>
	<div class="col-lg-8">
	<div class="ibox ">
	<div class="ibox-title">
	<h5><a href="<?php echo site_url('C_admin/daftar_penelitian')?>">Konfirmasi Penelitian</a></h5>
	</div>
	<div class="ibox-content table-responsive">
	<table class="table table-hover no-margins">
		<thead>
		<tr>
			<th>No</th>
			<th>NIM</th>
			<th>Judul Penelitian</th>
		</tr>
		</thead>
		<tbody>
		<?php 
		$no=1;
		foreach($admin_konfirmasi->result() as $aa){ 
		?>
		<tr>
			<td><?php echo $no++?></td>
			<td><?=$aa->id_peneliti;?></td> 
			<td><?=$aa->judul_penelitian;?></td> 
		</tr>
		 <?php 
		}
		?>
		</tbody>
	</table>
	</div>
	</div>
	</div>
</div>

<div class="row">
	<div class="col-md-3"></div>
	<div class="col-lg-4">
	<div class="ibox ">
	<div class="ibox-title">
	<h5><a href="<?php echo site_url('C_admin/bahan')?>">Stok Bahan Kurang Dari 10 ml/gr</a></h5>
	</div>
	<div class="ibox-content table-responsive">
	<table class="table table-hover no-margins">
		<thead>
		<tr>
			<th>No</th>
			<th>Nama Bahan</th>
			<th>Stok Bahan</th>
		</tr>
		</thead>
		<tbody>
		<?php 
		$no=1;
		foreach($admin_bahan_limit->result() as $bb){ 
		?>
		<tr>
			<td><?php echo $no++?></td>
			<td><?=$bb->nama_bahan;?></td> 
			<td><?=$bb->stok_bahan;?></td> 
		</tr>
		 <?php 
		}
		?>
		</tbody>
	</table>
	</div>
	</div>
	</div>

	
	<div class="col-lg-4">
	<div class="ibox">
	<div class="ibox-title">
	<h5><a href="<?php echo site_url('C_admin/alat')?>">Daftar Alat Rusak</a></h5>
	</div>
	<div class="ibox-content table-responsive">
	<table class="table table-hover no-margins">
		<thead>
		<tr>
			<th>No</th>
			<th>Nama Alat</th>
			<th>Status Alat</th>
		</tr>
		</thead>
		<tbody>
		<?php 
		$no=1;
		foreach($admin_alat_rusak->result() as $cc){ 
		?>
		<tr>
			<td><?php echo $no++?></td>
			<td><?=$cc->nama_alat;?></td> 
			<td><?=$cc->status_alat;?></td> 
		</tr>
		 <?php 
		}
		?>
		</tbody>
	</table>
	</div>
	</div>
	</div>
</div>
