<?php $this->load->view('header-akun');?>
<?php $this->load->view('sidebar-user');?>

<div id="content">
	<div class="col-md-2"></div>
	<div class="col-md-9">
	</br>
		<div class="jumbotron jumbotron-fluid">
  			<div class="container">
    			<h1 class="display-3">Selamat Datang!</h1>
    			<p class="lead">Ini merupakan dashboard untuk melakukan peminjaman alat dan pengajuan izin pemakaian Laboratorium Fakultas Teknologi Pertanian Universitas Andalas Padang</p>
  			</div>
		</div>
	</div>
</div>
