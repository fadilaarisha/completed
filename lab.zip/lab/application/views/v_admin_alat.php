<?php $this->load->view('header-akun');?>
<?php $this->load->view('sidebar-admin');?>


<div class="container">
<div class="row">
<div class="col-md-1"></div>
    <div class="col-lg-10">
        <div class="ibox float-e-margins">
            <div class="ibox-content">
				<form action="<?php echo site_url('C_alat/cari')?>" method="POST">
					<div class="col-lg-11"><input type="text" name= "cari_add"placeholder="Cari" class="form-control">
					</div>
					<div class="form-group row">
					<button class="btn btn-sm btn-info" type="submit">Cari</button>
					</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<div id="content">
<div class="container">
<div class="row">
    <div class="col-md-1"></div>
    <div class="col-lg-10">
        <div class="ibox float-e-margins">
            <div class="ibox-content">
                <div class="table-responsive">
					
					<a data-toggle="modal" class="btn btn-xs btn-info" href="#modal-add"><i class="fa fa-paste"></i> Tambah Alat</a>
					
					<a href="<?php echo site_url('C_alat/download')?>" class="btn btn-xs btn-danger" type="button" target="_blank">Download</a>
					
                    <table class="table table-hover">
                        <thead>
                        <tr>
                            <th>No</th>
							<th>Tanggal Update</th>
							<th>Nama</th>
							<th>Jumlah</th>
							<th>Fungsi</th>
							<th>Status</th>
							<th>Aksi</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php 
						$no=1;
						foreach($admin_alat->result() as $aa){ 
						?>							
						<tr>
						<td><?php echo $no++?></td>
						<td><?=$aa->tgl_update;?></td> 
						<td><?=$aa->nama_alat;?></td> 
						<td><?=$aa->jml_alat;?></td>
						<td><?=$aa->fungsi_alat;?></td> 
						<td><?=$aa->status_alat;?></td>		
						<td>
                                <a data-toggle="modal" class="btn btn-xs btn-info" href="#modal-edit<?php echo $aa->id_alat;?>"><i class="fa fa-paste"></i> Edit</a>
                                
                                <a href="<?php echo site_url('C_alat/hapus/'.$aa->id_alat)?>" class="btn btn-xs btn-danger" type="button"><i class="fa fa-times"></i>Delete</a>
                            </td>
                            <div id="modal-edit<?php echo $aa->id_alat;?>" class="modal fade" aria-hidden="true">
                                <div class="modal-dialog" style="width: 300px">
                                    <div class="modal-content">
                                        <div class="modal-body">
                                            <div class="row">
                                                <h3 class="m-t-none m-b">Edit data</h3>
                                                    <form role="form" action="<?php echo site_url('C_alat/edit/'.$aa->id_alat)?>" method="post">
                                                        <div class="form-group"><label>Nama Alat</label> <input type="text" name="nama_alat_edit" value="<?php echo $aa->nama_alat;?>" class="form-control"></div>
														<div class="form-group"><label>Jumlah Alat</label> <input type="number" name="jml_alat_edit" value="<?php echo $aa->jml_alat;?>" class="form-control"></div>
														<div class="form-group"><label>Fungsi Alat</label> <input type="text" name="fungsi_alat_edit" value="<?php echo $aa->fungsi_alat;?>" class="form-control"></div>
														
														<div class="form-group"><label>Status Alat</label>
<select class="form-control" name= "fungsi_alat_edit" value="<?php echo $aa->status_alat;?>" required="">
														<option>Baik</option>
														<option>Rusak</option>
														</select></div>
                                                            <button class="btn btn-sm btn-primary pull-right m-t-n-xs" type="submit"><strong>Simpan</strong></button>
                                                        </div>
                                                    </form>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </tr>
                        <?php 
                        }
                        ?>
                        </tbody>
                    </table>
					
					<div id="modal-add" class="modal fade" aria-hidden="true">
                                <div class="modal-dialog" style="width: 300px">
                                    <div class="modal-content">
                                        <div class="modal-body">
                                            <div class="row">
                                                <h3 class="m-t-none m-b">Tambah Alat</h3>
                                                    <form role="form" action="<?php echo site_url('C_alat/add/')?>" method="post">
                                                        <div class="form-group"><label>Nama Alat</label> <input type="text" name="nama_alat_add" class="form-control"></div>
														<div class="form-group"><label>Jumlah Alat</label> <input type="number" name="jml_alat_add" class="form-control"></div>
														<div class="form-group"><label>Fungsi Alat</label> <input type="text" name="fungsi_alat_add" class="form-control"></div>
														<div class="form-group"><label>Status Alat</label>
<select class="form-control" name= "status_alat_add" required="">
														<option>Baik</option>
														<option>Rusak</option>
														</select></div>
                                                            <button class="btn btn-sm btn-primary pull-right m-t-n-xs" type="submit" value="tambah"><strong>Tambah</strong></button>
                                                        </div>
                                                    </form>
                                                
                                            </div>
                                        </div>
										
                                    </div>
									
                                </div>
								
                            </div>
                </div>

            </div>
        </div>
    </div>
	