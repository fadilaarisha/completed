<?php $this->load->view('header-akun');?>
<?php $this->load->view('sidebar-admin');?>

<body>

<div class="container">
<div class="row">
<div class="col-md-1"></div>
    <div class="col-lg-10">
        <div class="ibox float-e-margins">
            <div class="ibox-content">
				<form action="<?php echo site_url('Daftar/cari')?>" method="POST">
					<div class="col-lg-11"><input type="text" name= "cari_add"placeholder="Cari" class="form-control">
					</div>
					<div class="form-group row">
					<button class="btn btn-sm btn-info" type="submit">Cari</button>
					</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>


<div id="content">
<div class="container">
<div class="row">
		<div class="col-md-1"></div>
		<div class="col-lg-10">
        <div class="ibox float-e-margins">
            <div class="ibox-content">
                <div class="table-responsive">
					
					<a data-toggle="modal" class="btn btn-xs btn-info" href="#modal-add"><i class="fa fa-paste"></i> Tambah Jadwal</a>
					
					<a href="<?php echo site_url('Daftar/download')?>" class="btn btn-xs btn-danger" type="button" target="_blank">Download</a>
					
					
                    <table class="table table-hover">
                        <thead>
                        <tr>
                            <th>No </th>
							<th>Nama Lengkap</th>
							<th>NIM</th>
							<th>Jurusan</th>
							<th>Fakultas</th>	
							<th>Alamat</th>	
							<th>No. HP</th>	
							<th>Email</th>	
							<th>Password</th>	
                        </tr>
                        </thead>
                        <tbody>
                        <?php 
						$no=1;
						foreach($admin_akun_peneliti->result() as $aa){ 
						?>							
						<tr>
						<td><?php echo $no++?></td>
						<td><?=$aa->nama_peneliti?></td> 
						<td><?=$aa->nim_peneliti;?></td> 
						<td><?=$aa->jurusan_peneliti;?></td> 
						<td><?=$aa->fakultas_peneliti;?></td>
						<td><?=$aa->alamat_peneliti;?></td>
						<td><?=$aa->nohp_peneliti;?></td>
						<td><?=$aa->email_peneliti;?></td>
						<td><?=$aa->pass_peneliti;?></td>
						<td>
                                <a data-toggle="modal" class="btn btn-xs btn-info" href="#modal-edit<?php echo $aa->nim_peneliti;?>"><i class="fa fa-paste"></i> Edit</a>
								<a href="<?php echo site_url('Daftar/hapus/'.$aa->nim_peneliti)?>" class="btn btn-xs btn-danger" type="button"><i class="fa fa-times"></i>Delete</a>
                       </td>
					   
					   <div id="modal-edit<?php echo $aa->nim_peneliti;?>" class="modal fade" aria-hidden="true">
                                <div class="modal-dialog" style="width: 300px">
                                    <div class="modal-content">
                                        <div class="modal-body">
                                            <div class="row">
                                                <h3 class="m-t-none m-b">Edit data</h3>
                                                    <form role="form" action="<?php echo site_url('Daftar/edit/'.$aa->nim_peneliti)?>" method="post">
                                                       <label>Nama Lengkap</label>
														<input type="text" class="form-control" name="nama_edit" value="<?php echo $aa->nama_peneliti;?>" required="silahkan isi nama lengkap anda">
													</div>
													<div class="form-group">
														<label>NIM</label>
														<input type="number" class="form-control" name="nim_edit" value="<?php echo $aa->nim_peneliti;?>" required="">
													</div>
													<div class="form-group">
														<label>Jurusan</label>
														<input type="text" class="form-control" name="jurusan_edit" value="<?php echo $aa->jurusan_peneliti;?>" required="">
													</div>
													<div class="form-group">
														<label>Fakultas</label>
														<input type="text" class="form-control" name="fakultas_edit" value="<?php echo $aa->fakultas_peneliti;?>" required="">
													</div>
													<div class="form-group">
														<label>No. HP</label>
														<input type="number" class="form-control" name="nohp_edit" value="<?php echo $aa->nohp_peneliti;?>" required="">
													</div>
													<div class="form-group">
														<label>Alamat Domisili</label>
														<input type="text" class="form-control" name="alamat_edit" value="<?php echo $aa->alamat_peneliti;?>" required="">
													</div><div class="form-group">
														<label>Email</label>
														<input type="email" class="form-control" name="email_edit" value="<?php echo $aa->email_peneliti;?>" required="">
													</div>
													<div class="form-group">
														<label>Password</label>
														<input type="password" class="form-control" name="password_edit" value="<?php echo $aa->pass_peneliti;?>" required="">
													</div>
                                                            <button class="btn btn-sm btn-primary pull-right m-t-n-xs" type="submit"><strong>Simpan</strong></button>
                                                        </div>
                                                    </form>
                                                
                                            </div>
                                        </div>
                                    </div>
					   
					</tr>
					<?php 
                        }
                        ?>
                        </tbody>
                    </table>
					
					<div id="modal-add" class="modal fade" aria-hidden="true">
                                <div class="modal-dialog" style="width: 300px">
                                    <div class="modal-content">
                                        <div class="modal-body">
                                            <div class="row">
                                                <h3 class="m-t-none m-b">Tambah Akun</h3>
                                                    <form role="form" action="<?php echo site_url('Daftar/add/')?>" method="POST">
													<div class="form-group">
														<label>Nama Lengkap</label>
														<input type="text" class="form-control" name="nama_daftar"required="silahkan isi nama lengkap anda">
													</div>
													<div class="form-group">
														<label>Nomor Induk Mahasiswa</label>
														<input type="number" class="form-control" name="nim_daftar"required="">
													</div>
													<div class="form-group">
														<label>Jurusan</label>
														<input type="text" class="form-control" name="jurusan_daftar"required="">
													</div>
													<div class="form-group">
														<label>Fakultas</label>
														<input type="text" class="form-control" name="fakultas_daftar"required="">
													</div>
													<div class="form-group">
														<label>No. HP</label>
														<input type="number" class="form-control" name="nohp_daftar"required="">
													</div>
													<div class="form-group">
														<label>Alamat Domisili</label>
														<input type="text" class="form-control" name="alamat_daftar"required="">
													</div><div class="form-group">
														<label>Email</label>
														<input type="email" class="form-control" name="email_daftar"required="">
													</div>
													<div class="form-group">
														<label>Password</label>
														<input type="password" class="form-control" name="password_daftar"required="">
													</div>
												<!--	<div class="form-group">
														<label>Foto</label>
														<input type="file" class="form-control" name="foto_daftar"required="">
													</div> -->
													<div class="text-right">
													
														<!-- Tombol Submit-->
														<button type="submit" class="btn btn-template-main"><i class="fa fa-user-md"></i> Simpan</button>
													
													</form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            
							</div>
                </div>

            </div>
        </div>
    </div>
</div>
    <script src="<?php echo base_url('assets/js/bootstrap-datepicker.js') ?>"></script>
	<script src="<?php echo base_url()?>'assets/js/jquery-3.1.1.min.js"></script>
		<script src="<?php echo base_url()?>assets/js/footable.all.min.js"></script>
</body>