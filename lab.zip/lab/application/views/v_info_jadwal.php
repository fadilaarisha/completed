<?php $this->load->view('header');?>

<div id="content">
            <div class="container">


                <div class="row">

                    <!-- *** LEFT COLUMN ***
			 _________________________________________________________ -->

                    <div class="col-md-9" id="customer-orders">
						<h1>Jadwal Praktikum</h1>
                        <p class="text-muted lead">Berikut Jadwal Praktikum di Laboratorium Mikrobiologi Fakultas Teknologi Pertanian Universitas Andalas Padang.</p>

                        <div class="box">

                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>No</th>
											<th>Hari</th>
                                            <th>Jam Awal</th>
                                            <th>Jam Akhir</th>
                                            <th>Nama Kegiatan</th>
                                        </tr>
                                    </thead>
                                    <tbody>
										<?php 
										$no=1;
										foreach($list_jadwal->result() as $j){ 
										?>									
										<tr>
										<td><?php echo $no++?></td>
										<td><?=$j->hari_keg;?></td> 
										<td><?=$j->jam_awal_keg;?></td>
										<td><?=$j->jam_akhir_keg;?></td>
										<td><?=$j->nama_keg;?></td>
										</tr>
									<?php } ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->

                        </div>
                        <!-- /.box -->

                    </div>
				</div>
			</div>
		</div>
					
 <?php $this->load->view('footer');?>