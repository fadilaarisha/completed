<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Laboratorium Mikrobiologi FATETA UNAND</title>

    <link href="<?php echo base_url()?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url()?>assets/awesome.css" rel="stylesheet">
    <link href="<?php echo base_url()?>assets/css/iCheck-custom.css" rel="stylesheet">
    <link href="<?php echo base_url()?>assets/css/animate.css" rel="stylesheet">
    <link href="<?php echo base_url()?>assets/css/style.css" rel="stylesheet">

</head>
<div class="row border-bottom">
    <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
   
    <ul class="nav navbar-top-links navbar-right">
        <li>
            <span class="m-r-sm text-muted welcome-message">Dashboard</span>
        </li>
        <li>
            <a href="<?php echo site_url('Login/logout')?>">
                <i class="fa fa-sign-out"></i> Log out
            </a>
        </li>
    </ul>

    </nav>
    </div>
<!-- Mainly scripts -->
    <script src="<?php echo base_url()?>assets/js/jquery-2.1.1.js"></script>
    <script src="<?php echo base_url()?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url()?>assets/js/metisMenu.js"></script>
    <script src="<?php echo base_url()?>assets/js/jquery.slimscroll.min.js"></script>

    <!-- Peity -->
    <script src="<?php echo base_url()?>assets/js/jquery.peity.min.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="<?php echo base_url()?>assets/js/inspinia.js"></script>
    <script src="<?php echo base_url()?>assets/js/pace.min.js"></script>

    <!-- iCheck -->
    <script src="<?php echo base_url()?>assets/js/icheck.min.js"></script>

    <!-- Peity -->
    <script src="<?php echo base_url()?>assets/js/peity-demo.js"></script>
