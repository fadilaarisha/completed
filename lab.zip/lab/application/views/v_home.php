 <?php $this->load->view('header');?>
 <!-- owl carousel css -->
 <head>
    <link href="<?php echo base_url();?>assets/css/owl.carousel.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/owl.theme.css" rel="stylesheet">
	</head>
	<body>
            <div class="home-carousel">
                <div class="dark-mask"></div>
                <div class="container">
                    <div class="homepage owl-carousel">
                        <div class="item">
                            <div class="row">
                                <div class="col-sm-12 left">
								<center>                           
								<h1>Selamat Datang</h1>
                                    <p>Laboratorium Mikrobiologi
                                        <br />Fakultas Teknologi Pertanian<br />Universitas Andalas Padang</p>
										</center>
                                </div>
                                
                            </div>
                        </div>
                        
                    </div>
                    <!-- /.project owl-slider -->
                </div>
            </div>

            <!-- *** HOMEPAGE CAROUSEL END *** -->
        </section>

        <section class="bar background-white">
            <div class="container">
                <div class="col-md-12">


                    <div class="row">
                        <div class="col-md-4">
                            <div class="box-simple">
                                <div class="icon">
                                    <i class="fa fa-desktop"></i>
                                </div>
                                <h3>Visi</h3>
                                <p>Menjadi Program Studi yang terkemuka dan bermartabat dalam pengembangan ilmu dan teknologi hasil pertanian tropik yang unggul dab inovatif untuk kesejahteraan masyarakat dan kejayaan bangsa</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="box-simple">
                                <div class="icon">
                                    <i class="fa fa-print"></i>
                                </div>
                                <h3>Misi</h3>
                                <p>Menyelenggarakan program pendidikan yang berkualitas tinggi sehingga mampu menghasilkan lulusan berkualitas dan mampu bersaing di pasar global <br /><br />Melaksanakan penelitian untuk menunjang pembangunan nasional dan pengembangan ilmu pengetahuan dan teknologi yang inovatif dan dapat memberikan kontribusi terhadap peningkatan produksi, mutu, dan nilai tambah komoditas unggulan daerah <br /><br />Melaksanakan pengabdian kepada masyarakat dan aktif berperan dalam pemecahan permasalahan yang dihadapi masyarakat dalam bidang teknologi dan industri hasil pertanian <br /><br />Meningkatkan kualitas tata kelola organisasi yang baik dan membangun jejaring dengan stakeholder yang efektif dan efisien
								</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="box-simple">
                                <div class="icon">
                                    <i class="fa fa-desktop"></i>
                                </div>
                                <h3>Tujuan</h3>
                                <p>Meningkatkan mutu dan relevansi pendidikan, penelitian, dan pengabdian pada masyarakat untuk menghasilkan lulusan yang berkualitas <br /><br />Meningkatkan dan memperluas kerjasama baik nasional maupun internasional untuk menunjang pendidikan penelitian, dan pengabdian masyarakat <br /><br />Meningkatkan mutu tata kelola untuk menunjang pendidikan, penelitian, dan pengabdian masyarakat </p>
                            </div>
                        </div>
                    </div>

                    
                    
                </div>
            </div>
			</body>
<!-- owl carousel -->
    <script src="<?php echo base_url();?>assets/js/owl.carousel.min.js"></script>
<?php $this->load->view('footer');?>