<?php $this->load->view('header');?>

<div id="content">
            <div class="container">


                <div class="row">

                    <!-- *** LEFT COLUMN ***
			 _________________________________________________________ -->

                    <div class="col-md-9" id="customer-orders">
						<h1>Informasi Pranata</h1>
                        <p class="text-muted lead">Berikut Informasi Pranata Laboratorium Mikrobiologi Fakultas Teknologi Pertanian Universitas Andalas Padang.</p>

                        <div class="box">

                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            
											<th>Nama</th>					
											<th>NIK</th>
                                            <th>Status</th>
											<th>Update</th>
                                        </tr>
                                    </thead>
                                    <tbody>
	<?php 
		$no= 1;
		foreach($info_pranata->result() as $a){ 
		?>									
		<tr>
		<td><?=$a->nama_admin;?></td> 
		<td><?=$a->id_admin;?></td>
		<td><?=$a->status_admin;?></td> 
		<td><?=$a->update_admin;?></td>								
		</tr>
	<?php } ?>								
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->

                        </div>
                        <!-- /.box -->

                    </div>
				</div>
			</div>
		</div>
		
	
	</div>

	<?php $this->load->view('footer');?>