 <?php $this->load->view('header');?>

		
	<div id="content">
        <div class="container">
			<div class="row">
				<div class="col-md-6">
                        <div class="box">
                            <h2 class="text-uppercase">Masuk</h2>

                            <p class="lead">Sudah memiliki akun?</p>
                            <p class="text-muted">Silahkan masukkan identitas dan password dengan tepat!</p>

                            <hr>

                            <form class="m-t" role="form" action="<?php echo site_url('Login/masuk')?>" method="post" >
                                <div class="form-group">
                                    <label for="id-masuk">NIM/NIK</label>
                                    <input type="number" class="form-control" name="id_masuk"required="">
                                </div>
                                <div class="form-group">
                                    <label for="password-masuk">Kata Sandi</label>
                                    <input type="password" class="form-control" name="pass_masuk"required="">
                                </div>
                                <div class="text-center">
                                    <button type="submit" class="btn btn-template-main"><i class="fa fa-sign-in"></i> Masuk</button>
                                </div>
                            </form>
                        </div>
                    </div>
				</div>
			</div>
		</div>

 <?php $this->load->view('footer');?>