<?php $this->load->view('header-akun');?>
<?php $this->load->view('sidebar-user');?>


<div class="container">
<div class="row">
    <div class="col-md-1"></div>
    <div class="col-lg-10">
     								
					<?php 
						foreach($akun_faq->result() as $aa){
					?>
                  
					<div class="ibox-content text-left css-animation-box">
                        <h1 class="text-navy">
                           <?php echo $aa->judul_info;?>
                        </h1>
                        <p>
                            <?php echo $aa->konten_info;?>
                        </p>
					</div>
                        
						<?php } ?>
								</div>
							</div>
						</div>
					</div>
		

			