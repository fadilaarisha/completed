<nav class="navbar-default navbar-static-side" role="navigation">
    <div class="container-fluid">
        <ul class="nav" id="side-menu">
            <li class="nav-header">
                
                    <a href="<?php echo site_url('C_user/setting')?>">
                        <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold">Hai, <?php echo $this->session->userdata('ses_nama');?> !</strong></span>
						<span class="text-muted text-xs block"><?php echo $this->session->userdata('ses_id');?> <b class="caret"></b></span> </span> </a>
                
               
            </li>
            
            <li>
                <a href="<?php echo site_url('C_user/home')?>"><i class="fa fa-home"></i> <span class="nav-label">Home</span></a>
				
            </li>
            <li>
                <a href="<?php echo site_url('C_user/daftar_penelitian')?>"><i class="fa fa-pencil"></i> <span class="nav-label">Daftar Penelitian</span></a>
				
            </li>
			<li>
                <a href="<?php echo site_url('C_user/jadwal_peneliti')?>"><i class="fa fa-pencil"></i> <span class="nav-label">Jadwal Penelitian</span></a>
				
            </li>
            <li>
                <a href="<?php echo site_url('C_user/setting')?>"><i class="fa fa-database"></i> <span class="nav-label">Pengaturan Akun</span></a>
            </li>
			<li>
                <a href="<?php echo site_url('C_user/faq_peneliti')?>"><i class="fa fa-database"></i> <span class="nav-label">FAQ</span></a>
            </li>
        </ul>

    </div>
</nav>