<?php $this->load->view('header');?>

<div id="content">
            <div class="container">


                <div class="row">

                    <!-- *** LEFT COLUMN ***
			 _________________________________________________________ -->

                    <div class="col-md-9" id="customer-orders">
						<h1>Jadwal Penelitian</h1>
                        <p class="text-muted lead">Berikut Jadwal Penelitian di Laboratorium Mikrobiologi Fakultas Teknologi Pertanian Universitas Andalas Padang.</p>

                        <div class="box">

                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>No </th>
											<th>Tanggal</th>
											<th>Waktu Mulai</th>
											<th>Waktu Selesai</th>
											<th>Nama Lengkap</th>	
											<th>NIM</th>	
											<th>Judul Penelitian</th>	
                                        </tr>
                                    </thead>
                                    <tbody>
										<?php 
										$no=1;
										foreach($jadwal_penelitian->result() as $aa){ 
										?>									
										<tr>
										<td><?php echo $no++?></td>
										<td><?=$aa->tgl_penelitian;?></td> 
										<td><?=$aa->jam_mulai;?></td> 
										<td><?=$aa->jam_selesai;?></td> 
										<td><?=$aa->nama_peneliti;?></td> 
										<td><?=$aa->nim_peneliti;?></td> 
										<td><?=$aa->judul_penelitian;?></td>
										</tr>
									<?php } ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->

                        </div>
                        <!-- /.box -->

                    </div>
				</div>
			</div>
		</div>
					
 <?php $this->load->view('footer');?>