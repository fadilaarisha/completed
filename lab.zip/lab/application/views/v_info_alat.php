<?php $this->load->view('header');?>

<div id="content">
            <div class="container">


                <div class="row">

                    <!-- *** LEFT COLUMN ***
			 _________________________________________________________ -->

                    <div class="col-md-9" id="customer-orders">
						<h1>Informasi Alat</h1>
                        <p class="text-muted lead">Berikut data alat yang tersedia di Laboratorium Mikrobiologi Fakultas Teknologi Pertanian Universitas Andalas Padang.</p>

                        <div class="box">

                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            
											<th>No</th>							
											<th>Nama</th>
                                            <th>Jumlah</th>
                                            <th>Fungsi</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
	<?php 
		$no= 1;
		foreach($list_alat->result() as $a){ 
		?>									
		<tr>
		<td><?php echo $no++?></td>
		<td><?=$a->nama_alat;?></td> 
		<td><?=$a->jml_alat;?></td>
		<td><?=$a->fungsi_alat;?></td> 
		<td><?=$a->status_alat;?></td>								
		</tr>
	<?php } ?>								
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->

                        </div>
                        <!-- /.box -->

                    </div>
				</div>
			</div>
		</div>
		
	
	</div>

	<?php $this->load->view('footer');?>