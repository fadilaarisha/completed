<?php $this->load->view('header-akun');?>
<?php $this->load->view('sidebar-admin');?>

<div id="content">
<div class="container">
<div class="row">
	<div class="col-md-1"></div>
    <div class="col-lg-8">
        <div class="ibox float-e-margins">
            <div class="ibox-content">
			<?php 
				foreach($admin_pengaturan->result() as $aa){ ?>	
			<p class="text-left"><label class="col-sm-2 col-form-label">Nama</label><?php echo $aa->nama_admin;?></p>
			<p class="text-left"><label class="col-sm-2 col-form-label">NIK</label><?php echo $aa->id_admin;?></p>
			<p class="text-left"><label class="col-sm-2 col-form-label">Status</label><?php echo $aa->status_admin;?></p>
			<p class="text-left"><label class="col-sm-2 col-form-label">Password</label><?php echo $aa->pass_admin;?></p>
			
			<a data-toggle="modal" class="btn btn-xs btn-info" href="#modal-edit<?php echo $aa->id_admin;?>"><i class="fa fa-paste"></i> Edit</a>
			
			 <div id="modal-edit<?php echo $aa->id_admin;?>" class="modal fade" aria-hidden="true">
				<div class="modal-dialog" style="width: 300px">
					<div class="modal-content">
						<div class="modal-body">
							<div class="row">
								<h3 class="m-t-none m-b">Edit data</h3>
									<form role="form" action="<?php echo site_url('C_admin_pengaturan/edit/'.$aa->id_admin)?>" method="post">
										<div class="form-group"><label>Nama</label> <input type="text" name="nama_edit" value="<?php echo $aa->nama_admin;?>" class="form-control"></div>
										<div class="form-group"><label>NIK</label> <input type="number" name="id_edit" min = "0" value="<?php echo $aa->id_admin;?>" class="form-control"></div>
										<div class="form-group"><label>Status</label>
										<select class="form-control" name= "status_edit" value="<?php echo $aa->status_admin;?>" required="">
														<option>Hadir</option>
														<option>Tidak Hadir </option>
														<option>Di Luar Ruangan </option>
										</select></div>
										<div class="form-group"><label>Password</label> <input type="text" name="pass_edit" value="<?php echo $aa->pass_admin;?>" class="form-control"></div>
										<button class="btn btn-sm btn-primary pull-right m-t-n-xs" type="submit"><strong>Simpan</strong></button>
										</div>
									</form>
								
							</div>
						</div>
					</div>

			<?php } ?>
			</div>
		</div>
	</div>
</div>
</div>
</div>
</div>