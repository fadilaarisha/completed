<?php $this->load->view('header-akun');?>
<?php $this->load->view('sidebar-admin');?>

<div class="container">
<div class="row">
<div class="col-md-1"></div>
    <div class="col-lg-10">
        <div class="ibox float-e-margins">
            <div class="ibox-content">
				<form action="<?php echo site_url('C_daftar_penelitian/cari')?>" method="POST">
					<div class="col-lg-11"><input type="text" name= "cari_add"placeholder="Cari" class="form-control">
					</div>
					<div class="form-group row">
					<button class="btn btn-sm btn-info" type="submit">Cari</button>
					</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<div id="content">
<div class="container">
<div class="row">
    <div class="col-md-1"></div>
    <div class="col-lg-11">
        <div class="ibox float-e-margins">
            <div class="ibox-content">
                <div class="table-responsive">
					
					<a data-toggle="modal" class="btn btn-xs btn-info" href="#modal-add"><i class="fa fa-paste"></i> Tambah Daftar</a>
					
					<a href="<?php echo site_url('C_daftar_penelitian/download')?>" class="btn btn-xs btn-danger" type="button" target="_blank">Download</a>
					
					
                    <table class="table table-hover">
                        <thead>
                        <tr>
                            <th>No</th>
							<th>Nama Lengkap</th>
							<th>NIM</th>
							<th>Judul Penelitian</th>
							<th>Dosen 1</th>
							<th>Dosen 2</th>
							<th>Mulai</th>
							<th>Berakhir</th>
							<th>Parameter Penelitian</th>
							<th>Status</th>
							<th>Catatan</th>
							
                        </tr>
                        </thead>
                        <tbody>
                        <?php 
						$no=1;
						foreach($hasil_cari->result() as $aa){ 
						?>							
						<tr>
						<td><?php echo $no++?></td>
						<td><?=$aa->nama_peneliti;?></td>
						<td><?=$aa->id_peneliti;?></td>
						<td><?=$aa->judul_penelitian;?></td> 
						<td><?=$aa->dosen1_penelitian;?></td>
						<td><?=$aa->dosen2_penelitian;?></td>
						<td><?=$aa->mulai_penelitian;?></td> 
						<td><?=$aa->akhir_penelitian;?></td> 		
						<td><?=$aa->parameter_penelitian;?></td>
						<td><?=$aa->status_penelitian;?></td>
						<td><?=$aa->catatan_penelitian;?></td>
						
						<td>
                                <a data-toggle="modal" class="btn btn-xs btn-info" href="#modal-edit<?php echo $aa->id_proposal;?>"><i class="fa fa-paste"></i> Edit</a>
                                
                                <a href="<?php echo site_url('C_daftar_penelitian/hapus/'.$aa->id_proposal)?>" class="btn btn-xs btn-danger" type="button"><i class="fa fa-times"></i>Delete</a>
                            </td>
                            <div id="modal-edit<?php echo $aa->id_proposal;?>" class="modal fade" aria-hidden="true">
                                <div class="modal-dialog" style="width: 300px">
                                    <div class="modal-content">
                                        <div class="modal-body">
                                            <div class="row">
                                                <h3 class="m-t-none m-b">Edit data</h3>
                                                    <form role="form" action="<?php echo site_url('C_daftar_penelitian/edit/'.$aa->id_proposal)?>" method="post">
                                                        <div class="form-group"><label>NIM</label> <input type="number" min="0" name="nim_edit" value="<?php echo $aa->nim_peneliti;?>" class="form-control" required=""></div>
														<div class="form-group"><label>Judul Penelitian</label> <input type="text" name="judul_penelitian_edit" value="<?php echo $aa->judul_penelitian;?>" class="form-control" required=""></div>
														<div class="form-group"><label>Dosbing 1 </label> <input type="text" name="dosen1_edit" value="<?php echo $aa->dosen1_penelitian;?>" class="form-control" required=""></div>
														<div class="form-group"><label>Dosbing 2 </label> <input type="text" name="dosen2_edit" value="<?php echo $aa->dosen2_penelitian;?>" class="form-control" required=""></div>
														<div class="form-group"><label>Tanggal Mulai </label> <input type="date" name="tanggal_mulai_edit" value="<?php echo $aa->mulai_penelitian;?>" class="form-control" required=""></div>
														<div class="form-group"><label>Tanggal Selesai</label> <input type="date" name="tanggal_selesai_edit" value="<?php echo $aa->akhir_penelitian;?>" class="form-control" required=""></div>
														<div class="form-group"><label>Parameter Penelitian</label>
														<select class="form-control" name= "parameter_edit" value="<?php echo $aa->parameter_penelitian;?>" required="">
														<option>Menentukan angka lempeng total mikroba</option>
														<option>Menentukan angka lempeng total jamur dan kapang</option>
														<option>Menentukan angka lempeng total Bakteri Asam Laktat</option>
														<option>Uji antimikroba</option>>
														</select>
														</div>
														<div class="form-group"><label>Status Penelitian</label>
														<select class="form-control" name= "status_edit" value="<?php echo $aa->status_penelitian;?>" required="">
														<option>Menunggu Konfirmasi</option>
														<option>Aktif</option>
														<option>Selesai</option>
														</select>
														</div>
														<div class="form-group"><label>Catatan Penelitian </label> <input type="text" name="catatan_edit" value="<?php echo $aa->catatan_penelitian;?>" class="form-control" required=""></div>
                                                        <button class="btn btn-sm btn-primary pull-right m-t-n-xs" type="submit"><strong>Simpan</strong></button>
                                                        </div>
														
                                                    </form>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>        
                        </tr>
                        <?php 
                        }
                        ?>
                        </tbody>
                    </table>
					
					<div id="modal-add" class="modal fade" aria-hidden="true">
                                <div class="modal-dialog" style="width: 300px">
                                    <div class="modal-content">
                                        <div class="modal-body">
                                            <div class="row">
                                                <h3 class="m-t-none m-b">Tambah Data</h3>
                                                    <form role="form" action="<?php echo site_url('C_daftar_penelitian/add/')?>" method="post">
                                                        <div class="form-group"><label>NIM</label> <input type="number" min="0" name="nim_add" class="form-control" required=""></div>
														<div class="form-group"><label>Judul Penelitian</label> <input type="text" name="judul_penelitian_add" class="form-control" required=""></div>
														<div class="form-group"><label>Dosbing 1 </label> <input type="text" name="dosen1_add"  class="form-control" required=""></div>
														<div class="form-group"><label>Dosbing 2 </label> <input type="text" name="dosen2_add"  class="form-control" required=""></div>
														<div class="form-group"><label>Tanggal Mulai </label> <input type="date" name="tanggal_mulai_add" class="form-control" required=""></div>
														<div class="form-group"><label>Tanggal Selesai</label> <input type="date" name="tanggal_selesai_add" class="form-control" required=""></div>
														<div class="form-group"><label>Parameter Penelitian</label>
														<select class="form-control" name= "parameter_add"  required="">
														<option>Menentukan angka lempeng total mikroba</option>
														<option>Menentukan angka lempeng total jamur dan kapang</option>
														<option>Menentukan angka lempeng total Bakteri Asam Laktat</option>
														<option>Uji antimikroba</option>>
														</select>
														</div>
														<div class="form-group"><label>Status Penelitian</label>
														<select class="form-control" name= "status_add" required="">
														<option>Menunggu Konfirmasi</option>
														<option>Aktif</option>
														<option>Selesai</option>
														</select>
														</div>
														<div class="form-group"><label>Catatan Penelitian </label> <input type="text" name="catatan_add" class="form-control" required=""></div>
                                                        <button class="btn btn-sm btn-primary pull-right m-t-n-xs" type="submit"><strong>Simpan</strong></button>
                                                        </div>
														
                                                    </form>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
								
								</br>
<a href="<?php echo site_url('C_admin/daftar_penelitian')?>" class="btn btn-sm btn-danger" type="button">Kembali</a>	
								
                            </div>
                </div>

            </div>
        </div>
    </div>
	</div>
	</div>