<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class C_admin_pengaturan extends CI_Controller {

    public function __construct() {
		parent::__construct();		
		$this->load->model('app_model');
                $this->load->helper('url');
		
    //    parent::__construct();
    //  date_default_timezone_set('Asia/Jakarta');
    //    if ($this->session->logged_in == FALSE) {
			// redirect them to the login page
	//		redirect('auth/logout', 'refresh');
	//	} else {
            /* load the models */
                        
    //    }
    }
	
	public function edit ($id){
		$nama_edit = $this->input->post('nama_edit');
		$id_edit = $this->input->post('id_edit');
		$status_edit = $this->input->post('status_edit');
		$pass_edit = $this->input->post('pass_edit');
		
		$data_edit = array(
        	'nama_admin' => $nama_edit,
        	'id_admin'=> $id_edit,
			'status_admin'=> $status_edit,
			'pass_admin'=> $pass_edit);
		
		$this->app_model->updateData("akun_admin", "id_admin", $id, $data_edit);
		redirect('c_admin/pengaturan');
	}
	
}

?>		