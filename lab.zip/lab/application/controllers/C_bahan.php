<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class C_bahan extends CI_Controller {

    public function __construct() {
		parent::__construct();		
		$this->load->model('app_model');
		$this->load->model('search_model');
		$this->load->model('Users_model');
		$this->load->helper('url');
		$this->load->library('pdf');
		
    //    parent::__construct();
    //  date_default_timezone_set('Asia/Jakarta');
    //    if ($this->session->logged_in == FALSE) {
			// redirect them to the login page
	//		redirect('auth/logout', 'refresh');
	//	} else {
            /* load the models */
                        
    //    }
    }
	
	public function add(){
		$nama_bahan_add = $this->input->post('nama_bahan_add');
		$stok_bahan_add = $this->input->post('stok_bahan_add');
		$harga_bahan_add = $this->input->post('harga_bahan_add');
		$id_bahan_add = $this->Users_model->kode_bahan();
		
	  $data_register = array(
        	'id_bahan' => $id_bahan_add,
			'nama_bahan' => $nama_bahan_add,
        	'stok_bahan'=>$stok_bahan_add,
        	'harga_bahan'=>$harga_bahan_add);
						
        $this->app_model->addData("bahan", $data_register);
        
		redirect('c_admin/bahan'); 
	}
	
	public function edit($id){
		$nama_bahan_edit = $this->input->post('nama_bahan_edit');
		$stok_bahan_edit = $this->input->post('stok_bahan_edit');
		$harga_bahan_edit = $this->input->post('harga_bahan_edit');
		
	  $data_edit = array(
        	'nama_bahan' => $nama_bahan_edit,
        	'stok_bahan'=>$stok_bahan_edit,
        	'harga_bahan'=>$harga_bahan_edit);
						
        $this->app_model->updateData("bahan", "id_bahan", $id, $data_edit);
        
		redirect('c_admin/bahan');
	}
	
	function hapus($id){
		$this->app_model->hapus("bahan","id_bahan", $id);
		$this->session->set_flashdata('item','<div class="alert alert-danger" role="alert">Well done! You successfully read this important alert message.</div>');
		redirect('c_admin/bahan'); 
	}
	
	function cari(){
		$cari_add = $this->input->post('cari_add');
		$data["hasil_cari"] = $this->search_model->getCariBahan($cari_add);
		$this->load->view('v_admin_hasil_bahan',$data);	
	}
	
	function download(){
        $pdf = new FPDF('p','mm','A4');
        // membuat halaman baru
        $pdf->AddPage();
        // setting jenis font yang akan digunakan
        $pdf->SetFont('Arial','B',16);
        // mencetak string 
        $pdf->Cell(190,7,'LABORATORIUM MIKROBIOLOGI',0,1,'C');
        $pdf->SetFont('Arial','B',16);
        $pdf->Cell(190,7,'FAKULTAS TEKNOLOGI PERTANIAN',0,1,'C');
		$pdf->SetFont('Arial','B',16);
        $pdf->Cell(190,7,'UNIVERSITAS ANDALAS',0,1,'C');
		
		$pdf->Cell(190,7,'',0,1);
		$pdf->SetFont('Arial','B',16);
        $pdf->Cell(190,7,'REKAPAN BAHAN KIMIA',0,1,'C');
        
		// Memberikan space kebawah agar tidak terlalu rapat
        $pdf->Cell(10,7,'',0,1);
        $pdf->SetFont('Arial','B',10);
        $pdf->Cell(130,6,'Nama Bahan',1,0);
        $pdf->Cell(30,6,'Stok Bahan',1,0, 'C');
        $pdf->Cell(30,6,'Harga Bahan',1,1, 'C');
        $pdf->SetFont('Arial','',12);
        $bahan = $this->app_model->getSorted('bahan', 'nama_bahan')->result();
        foreach ($bahan as $row){
            $pdf->Cell(130,6,$row->nama_bahan,1,0);
            $pdf->Cell(30,6,$row->stok_bahan,1,0, 'C');
            $pdf->Cell(30,6,$row->harga_bahan,1,1, 'C');
        }
		$pdf->Cell(10,7,'',0,1);
		$pdf->SetFont('Arial','I',10);
        $pdf->Cell(190,7,'Diunduh pada '. date("l, d-m-Y"),0,1,'C');
        $pdf->Output();
    }
	
	}
			
	?>	