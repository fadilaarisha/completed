<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_home extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 
	 function __construct(){
		parent::__construct();		
		$this->load->model('app_model');
		$this->load->model('Users_model');
                $this->load->helper('url');
	}
	 
	public function masuk()
	{
		$this->load->view('v_masuk');
	}

	public function daftar(){
		$this->load->view('v_daftar');
	}
	
	public function pranata(){
		$data["info_pranata"] = $this->app_model->getNoSort("akun_admin");
		$this->load->view('v_info_pranata', $data);
	}
	
	public function alat(){
		$data["list_alat"] = $this->app_model->getNoSort("alat");
		$this->load->view('v_info_alat',$data);
	}
	
	public function bahan(){
		$data["list_bahan"] = $this->app_model->getNoSort("bahan");
		$this->load->view('v_info_bahan',$data);
		
	}
	
	public function jadwal(){
		$data["list_jadwal"] = $this->app_model->getNoSort("jadwal");
		$this->load->view('v_info_jadwal',$data);
		
	}
	
	public function jadwal_penelitian(){
		$data["jadwal_penelitian"] = $this->Users_model->tampil_jadwalPenelitianAdmin();
		$this->load->view('v_info_jadwal_penelitian',$data);
		
	}
	
	public function faq_pengunjung(){
		$data["faq_pengunjung"] = $this->app_model->getWhere("info", "id_info", 1);
		$this->load->view('v_faq', $data);
	}
	
	public function profil(){
		$data["profil"] = $this->app_model->getWhere("info", "id_info", 3);
		$this->load->view('v_info_profil', $data);
	}
	
	public function home_admin(){
		$this->load->view('v_admin_home');
	}
}
