<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Daftar extends CI_Controller {
	
	
	function __construct(){
		parent::__construct();
		$this->load->model('app_model');
		$this->load->helper('url');
		$this->load->library('pdf');
		$this->load->model('search_model');
	}
	function index(){
        $this->load->view('v_daftar');
    }
		
	function add(){
		//definisi variabel input
		$nama_daftar = $this->input->post('nama_daftar');
		$email_daftar = $this->input->post('email_daftar');
		$nohp_daftar = $this->input->post('nohp_daftar');
		$alamat_daftar= $this->input->post('alamat_daftar');
		$password_daftar = $this->input->post('password_daftar');
		$jurusan_daftar = $this->input->post('jurusan_daftar');
		$fakultas_daftar = $this->input->post('fakultas_daftar');
		$nim_daftar = $this->input->post('nim_daftar');
		
		/* //konfigurasi foto
		$config['max_size']=10000;
		$config['allowed_types']='png|jpg|jpeg';
		$config['upload_path']='./upload/foto_peneliti/';
		$config['overwrite']= FALSE;
		
		$this->load->library('upload', $config);

		//ambil data image
		if (! $this->upload->do_upload('foto_daftar')){
			$error = array('error' => $this->upload->display_errors());
			redirect(site_url('Welcome'));
			}
		else{
			$upload_data = $this->upload->data();
			
			$foto_daftar = $upload_data['file_name'];
				 */
			$cek_data = $this->app_model->cek_data('akun_peneliti', 'nim_peneliti', $nim_daftar);
			
			$id_admin = $this->session->userdata('ses_id');
			$cek_admin = $this->app_model->cek_data('akun_admin', 'id_admin', $id_admin);
				
			if ($cek_data == FALSE){
				$data_register = array(
					'nama_peneliti'=>$nama_daftar,
					'email_peneliti'=>$email_daftar,
					'pass_peneliti'=>$password_daftar,
					'nohp_peneliti'=> $nohp_daftar,
					'alamat_peneliti'=> $alamat_daftar,
					'jurusan_peneliti'=> $jurusan_daftar,
					'fakultas_peneliti'=> $fakultas_daftar,
					'nim_peneliti'=> $nim_daftar);
				$this->app_model->addData('akun_peneliti', $data_register);
				if ($cek_admin = TRUE) {
					redirect(site_url('c_admin/akun_peneliti'));
				}
				else{
				redirect(site_url('Login'));}
			}
			else {
				if ($cek_admin = TRUE) {
					redirect(site_url('c_admin/akun_peneliti'));
				}
				else {
				redirect(site_url('Daftar'));
				}
		}
	}
	
	public function edit($id){
		$nama_edit = $this->input->post('nama_edit');
		$email_edit = $this->input->post('email_edit');
		$nohp_edit = $this->input->post('nohp_edit');
		$alamat_edit= $this->input->post('alamat_edit');
		$password_edit = $this->input->post('password_edit');
		$jurusan_edit = $this->input->post('jurusan_edit');
		$fakultas_edit = $this->input->post('fakultas_edit');
		$nim_edit = $this->input->post('nim_edit');
		
	  $data_edit = array(
		'nama_peneliti'=>$nama_edit,
		'email_peneliti'=>$email_edit,
		'pass_peneliti'=>$password_edit,
		'nohp_peneliti'=> $nohp_edit,
		'alamat_peneliti'=> $alamat_edit,
		'jurusan_peneliti'=> $jurusan_edit,
		'fakultas_peneliti'=> $fakultas_edit,
		'nim_peneliti'=> $nim_edit);
					
        $this->app_model->updateData("akun_peneliti", "nim_peneliti", $id, $data_edit);
        
		redirect('c_admin/akun_peneliti');
	}
	
	function hapus($id){
	//	$this->session->set_flashdata('item','<div class="alert alert-danger" role="alert">Well done! You successfully read this important alert message.</div>');
			$this->app_model->hapus('jadwal_penelitian','id_peneliti', $id);	
			$this->app_model->hapus('data_penelitian','id_peneliti', $id);	
			$this->app_model->hapus('akun_peneliti','nim_peneliti', $id);	
			redirect('c_admin/akun_peneliti');
	}
	
	function cari(){
		$cari_add = $this->input->post('cari_add');
		$data["hasil_cari"] = $this->search_model->getCariAkun($cari_add);
		$this->load->view('v_admin_hasil_akun',$data);	
	}
	
	function download(){
        $pdf = new FPDF('l','mm','A4');
        // membuat halaman baru
        $pdf->AddPage();
        // setting jenis font yang akan digunakan
        $pdf->SetFont('Arial','B',16);
        // mencetak string 
        $pdf->Cell(270,7,'LABORATORIUM MIKROBIOLOGI',0,1,'C');
        $pdf->SetFont('Arial','B',16);
        $pdf->Cell(270,7,'FAKULTAS TEKNOLOGI PERTANIAN',0,1,'C');
		$pdf->SetFont('Arial','B',16);
        $pdf->Cell(270,7,'UNIVERSITAS ANDALAS',0,1,'C');
		
		$pdf->Cell(250,7,'',0,1);
		$pdf->SetFont('Arial','B',16);
        $pdf->Cell(270,7,'REKAPAN AKUN PENELITI',0,1,'C');
        
		// Memberikan space kebawah agar tidak terlalu rapat
        $pdf->Cell(10,7,'',0,1);
        $pdf->SetFont('Arial','B',10);
        $pdf->Cell(50,15,'Nama',1,0);
        $pdf->Cell(30,15,'NIM',1,0, 'C');
		$pdf->Cell(30,15,'Jurusan',1,0, 'C');
		$pdf->Cell(30,15,'Fakultas',1,0, 'C');
		$pdf->Cell(50,15,'Email',1,0, 'C');
		$pdf->Cell(30,15,'No. HP',1,0, 'C');
        $pdf->Cell(60,15,'Alamat',1,1, 'C');
        $pdf->SetFont('Arial','',12);
        $akun = $this->app_model->getSorted('akun_peneliti', 'nama_peneliti')->result();
        foreach ($akun as $row){
            $pdf->Cell(50,15,$row->nama_peneliti,1,0);
            $pdf->Cell(30,15,$row->nim_peneliti,1,0, 'C');
			$pdf->Cell(30,15,$row->jurusan_peneliti,1,0, 'C');
			$pdf->Cell(30,15,$row->fakultas_peneliti,1,0, 'C');
			$pdf->Cell(50,15,$row->email_peneliti,1,0, 'C');
			$pdf->Cell(30,15,$row->nohp_peneliti,1,0, 'C');
			$pdf->Cell(60,15,$row->alamat_peneliti,1,1, 'C');
        }
		$pdf->Cell(10,7,'',0,1);
		$pdf->SetFont('Arial','I',10);
        $pdf->Cell(270,7,'Diunduh pada '. date("l, d-m-Y"),0,1,'C');
        $pdf->Output();
    }

	
	}		
		

?>