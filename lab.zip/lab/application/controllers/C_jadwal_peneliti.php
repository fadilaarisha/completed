<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class C_jadwal_peneliti extends CI_Controller {

    function __construct() {
		parent::__construct();		
		$this->load->model('app_model');
		$this->load->model('Users_model');
        $this->load->helper('url');
		$this->load->helper('date');
		
    //    parent::__construct();
    date_default_timezone_set('Asia/Jakarta');
    //    if ($this->session->logged_in == FALSE) {
			// redirect them to the login page
	//		redirect('auth/logout', 'refresh');
	//	} else {
            /* load the models */
                        
    //    }
    }
	
	function add(){
		$judul_peneliti_add = $this->input->post('judul_peneliti_add');
		$tanggal_peneliti_add = $this->input->post('tanggal_peneliti_add');
		$jam_mulai_add = $this->input->post('jam_mulai_add');
		$jam_selesai_add = $this->input->post('jam_selesai_add');
		$nim_add = $this->input->post('nim_add');
		$nim_user= $this->session->userdata('ses_id');
	//	$id_proposal_add = (int) $this->app_model->getColumnWhere('data_penelitian', 'id_proposal', 'judul_penelitian', $judul_peneliti_add);

		
		$login_user = $this->app_model->cek_data('akun_admin', 'id_admin', $nim_user);

		if ($login_user == FALSE){
			$data_register = array(
						'id_peneliti' => $nim_user,
						'judul_penelitian' => $judul_peneliti_add,
						'tgl_penelitian' => $tanggal_peneliti_add,
						'jam_mulai' => $jam_mulai_add,
						'jam_selesai' => $jam_selesai_add);
						
					$this->app_model->addData('jadwal_penelitian', $data_register);
					redirect('c_user/jadwal_peneliti'); 
					}	
				
		else {
			$cek_data = $this->Users_model->data_aktif_admin($nim_add, $judul_peneliti_add, "Aktif");
			if ($cek_data == TRUE) {
			$data_register = array(
					'id_peneliti' => $nim_add,
					'judul_penelitian' => $judul_peneliti_add,
					'tgl_penelitian' => $tanggal_peneliti_add,
					'jam_mulai' => $jam_mulai_add,
					'jam_selesai' => $jam_selesai_add);
					
				$this->app_model->addData('jadwal_penelitian', $data_register);
			redirect ('c_admin/jadwal_penelitian');}
			
			else {
				redirect ('c_admin/jadwal_penelitian');}
		}
	
	}
	
	function edit($id){
		$judul_peneliti_edit = $this->input->post('judul_peneliti_edit');
		$tanggal_peneliti_edit = $this->input->post('tanggal_peneliti_edit');
		$jam_mulai_edit = $this->input->post('jam_mulai_edit');
		$jam_selesai_edit = $this->input->post('jam_selesai_edit');
		$nim_edit = $this->input->post('nim_edit');
		
		$cek_data = $this->Users_model->data_aktif_admin($nim_edit, $judul_proposal_edit, "Aktif");
		
		if ($cek_data == TRUE){
			$data_edit = array(
				'id_peneliti' => $nim_edit,
				'judul_penelitian' => $judul_peneliti_edit,
				'tgl_penelitian' => $tanggal_peneliti_edit,
				'jam_mulai' => $jam_mulai_edit,
				'jam_selesai' => $jam_selesai_edit);
						
			$this->app_model->updateData("jadwal_penelitian", "id_jadwal", $id, $data_edit);
			
			redirect('c_admin/jadwal_penelitian');
			}
			
		else{
			redirect('c_admin/home');
		}
	}
		
	function hapus($id){
		$this->app_model->hapus('jadwal_penelitian','id_jadwal', $id);
		$id_user= $this->session->userdata('ses_id');
		$login_user = $this->app_model->cek_data("akun_peneliti", "nim_peneliti", $id_user);
		if ($login_user == FALSE){
			redirect('c_admin/jadwal_penelitian');
			 }
		else{
			redirect('c_user/jadwal_peneliti');
			}
	}
	

			}
			
	?>	