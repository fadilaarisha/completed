<?php
/**
*
*/
class Header extends CI_Controller
{
    function index()
    {
        $this->load->view('header');
    }
}