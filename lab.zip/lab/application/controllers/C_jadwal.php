<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class C_jadwal extends CI_Controller {

    public function __construct() {
		parent::__construct();		
		$this->load->model('app_model');
                $this->load->helper('url');
		
    //    parent::__construct();
    //  date_default_timezone_set('Asia/Jakarta');
    //    if ($this->session->logged_in == FALSE) {
			// redirect them to the login page
	//		redirect('auth/logout', 'refresh');
	//	} else {
            /* load the models */
                        
    //    }
    }
	
	public function add(){
		$nama_keg_add = $this->input->post('nama_keg_add');
		$hari_keg_add = $this->input->post('hari_keg_add');
		$jam_awal_keg_add = $this->input->post('jam_awal_keg_add');
		$jam_akhir_keg_add = $this->input->post('jam_akhir_keg_add');
		
	  $data_register = array(
        	'nama_keg' => $nama_keg_add,
        	'hari_keg'=>$hari_keg_add,
        	'jam_awal_keg'=>$jam_awal_keg_add,
			'jam_akhir_keg'=>$jam_akhir_keg_add);
			
        $this->app_model->addData("jadwal", $data_register);
        
		redirect('c_admin/jadwal'); 
	}
	
	public function edit ($id){
		$nama_keg_edit = $this->input->post('nama_keg_edit');
		$hari_keg_edit = $this->input->post('hari_keg_edit');
		$jam_awal_keg_edit = $this->input->post('jam_awal_keg_edit');
		$jam_akhir_keg_edit = $this->input->post('jam_akhir_keg_edit');
		
		$data_edit = array(
        	'nama_keg' => $nama_keg_edit,
        	'hari_keg'=>$hari_keg_edit,
        	'jam_awal_keg'=>$fungsi_keg_edit,
			'jam_akhir_keg'=>$jam_akhir_keg_edit);
		
		$this->app_model->updateData("jadwal", "id_keg", $id, $data_edit);
		redirect('c_admin/jadwal');
	}
	
	
	
	function hapus($id){
		$this->app_model->hapus("jadwal","id_keg", $id);
		$this->session->set_flashdata('item','<div class="alert alert-info" role="alert">Data Berhasil Di Hapus</div>');
		redirect('c_admin/jadwal'); 
	}
			}
			
		