<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class C_transaksi extends CI_Controller {

    public function __construct() {
		parent::__construct();		
		$this->load->model('app_model');
		$this->load->model('Users_model');
                $this->load->helper('url');
		
    //    parent::__construct();
    //  date_default_timezone_set('Asia/Jakarta');
    //    if ($this->session->logged_in == FALSE) {
			// redirect them to the login page
	//		redirect('auth/logout', 'refresh');
	//	} else {
            /* load the models */
                        
    //    }
    }
	
	public function add(){
		$nama_pelaku_add = $this->input->post('nama_pelaku_add');
		$jenis_transaksi_add = $this->input->post('jenis_transaksi_add');
		$nama_bahan_add = $this->input->post('nama_bahan_add');
		$jumlah_transaksi_add = $this->input->post('jumlah_transaksi_add');
		$id_bahan_add = $this->app_model->getValue('bahan', 'id_bahan', 'nama_bahan', $nama_bahan_add);
		$harga_bahan = $this->app_model->getValue('bahan', 'harga_bahan', 'id_bahan', $id_bahan_add);
		$harga_transaksi_add = intval ($harga_bahan) * intval ($jumlah_transaksi_add);
		$stok_lama= $this->app_model->getValue('bahan', 'stok_bahan', 'id_bahan', $id_bahan_add);
		$pembelian_add = intval ($stok_lama) +  $jumlah_transaksi_add;
		$penjualan_add = intval ($stok_lama) - $jumlah_transaksi_add;
		//$harga_bahan = $this->app_model->getColumnWhere('bahan', 'harga_bahan', 'nama_bahan', $nama_bahan_add);
	//	$harga_bahan = (int) $get_harga_bahan;
	//	(int)$harga_transaksi_add = (float)$jumlah_transaksi * (float)$harga_bahan;
		 
		
	  $data_register = array(
        	'nama_transaksi' => $nama_pelaku_add,
        	'jenis_transaksi'=>$jenis_transaksi_add,
			'id_bahan' => $id_bahan_add,
			'jumlah_transaksi'=>$jumlah_transaksi_add,
			'harga_transaksi' => $harga_transaksi_add);
	 
		if ($jenis_transaksi_add == "Penjualan"){
			if ($stok_lama >= $jumlah_transaksi_add){
				$this->app_model->addData("transaksi", $data_register);
				
				$data_edit = array(
					'nama_bahan' => $nama_bahan_add,
					'harga_bahan'=>$harga_bahan,
					'stok_bahan'=>$penjualan_add);
								
				$this->app_model->updateData("bahan", "id_bahan", $id_bahan_add, $data_edit);
				redirect('c_admin/transaksi');}
				
			else{
				redirect('c_admin/home');
				}
		}
		
		else {
			$this->app_model->addData("transaksi", $data_register);
			$data_edit = array(
				'nama_bahan' => $nama_bahan_add,
				'harga_bahan'=>$harga_bahan,
				'stok_bahan'=>$pembelian_add);
							
			$this->app_model->updateData("bahan", "id_bahan", $id_bahan_add, $data_edit);
			
			redirect('c_admin/transaksi');
		}
	}
	
	function edit($id){
		$nama_pelaku_edit = $this->input->post('nama_pelaku_edit');
		$jenis_transaksi_edit = $this->input->post('jenis_transaksi_edit');
		$nama_bahan_edit = $this->input->post('nama_bahan_edit');
		$jumlah_transaksi_edit = $this->input->post('jumlah_transaksi_edit');
		$id_bahan = $this->app_model->getValue('bahan', 'id_bahan', 'nama_bahan', $nama_bahan_edit);
		$stok_lama = $this->app_model->getValue('bahan', 'stok_bahan', 'id_bahan', $id_bahan);
		$penjualan_edit = intval ($stok_lama) - $jumlah_transaksi_edit;
		$pembelian_edit = intval ($stok_lama) + $jumlah_transaksi_edit;
		$harga_bahan = $this->app_model->getValue('bahan', 'harga_bahan', 'id_bahan', $id_bahan);
		$harga_transaksi_edit = $jumlah_transaksi_edit * intval ($harga_bahan);
		
		$data_edit = array(
        	'nama_transaksi' => $nama_pelaku_edit,
        	'jenis_transaksi'=>$jenis_transaksi_edit,
			'id_bahan' => $id_bahan_edit,
			'jumlah_transaksi'=>$jumlah_transaksi_edit,
			'harga_transaksi' => $harga_transaksi_edit);
	
		if ($jenis_transaksi_edit == "Penjualan"){
			if ($stok_lama >= $jumlah_transaksi_edit){
					$bahan_edit = array(
					'nama_bahan' => $nama_bahan_edit,
					'harga_bahan'=>$harga_bahan,
					'stok_bahan'=> $penjualan_edit);
				
				$this->app_model->updateData("transaksi", "id_transaksi", $id, $data_edit);
				$this->app_model->updateData("bahan", "id_bahan", $id_bahan, $bahan_edit);
				redirect('c_admin/transaksi');	
				}
				else {
					redirect('c_admin/home');}
			}
			
		else {
			$this->app_model->updateData("transaksi", "id_transaksi", $id, $data_edit);	
			$bahan_edit = array(
				'nama_bahan' => $nama_bahan_edit,
				'stok_bahan'=>$pembelian_edit,
				'harga_bahan'=>$harga_bahan);
				
			$this->app_model->updateData("transaksi", "id_transaksi", $id, $data_edit);				
			$this->app_model->updateData("bahan", "id_bahan", $id_bahan, $bahan_edit);
			redirect('c_admin/transaksi');	
			}
	}
	
	function hapus($id){
		
		$id_bahan = $this->app_model->getValue('transaksi', 'id_bahan', 'id_transaksi', $id);
		$stok_lama = $this->app_model->getValue('bahan', 'stok_bahan', 'id_bahan', $id_bahan);
		$jumlah_transaksi = $this->app_model->getValue('transaksi', 'jumlah_transaksi', 'id_transaksi', $id);
		$penjualan_batal = floatval ($stok_lama) + floatval ($jumlah_transaksi);
		$pembelian_batal = floatval ($stok_lama) - floatval ($jumlah_transaksi);
		$jenis_transaksi = $this->app_model->getValue('transaksi', 'jenis_transaksi', 'id_transaksi', $id);
		$nama_bahan = $this->app_model->getValue('bahan', 'nama_bahan', 'id_bahan', $id_bahan);
		$harga_bahan = $this->app_model->getValue('bahan', 'harga_bahan', 'id_bahan', $id_bahan);
				
		if ($jenis_transaksi == "Penjualan"){
			$data_edit = array(
				'nama_bahan' => $nama_bahan,
				'harga_bahan'=>$harga_bahan,
				'stok_bahan'=>$penjualan_batal);
							
			$this->app_model->updateData("bahan", "id_bahan", $id_bahan, $data_edit);
		}
		
		else {
			$data_edit = array(
				'nama_bahan' => $nama_bahan,
				'harga_bahan'=>$harga_bahan,
				'stok_bahan'=>$pembelian_batal);
							
			$this->app_model->updateData("bahan", "id_bahan", $id_bahan, $data_edit);
		} 
		
		$this->app_model->hapus("transaksi","id_transaksi", $id);
		$this->session->set_flashdata('item','<div class="alert alert-danger" role="alert">Well done! You successfully read this important alert message.</div>');
		redirect('c_admin/transaksi'); 
	}

			}
			
	?>	