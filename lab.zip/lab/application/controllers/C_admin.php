<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_admin extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 
	 function __construct(){
		parent::__construct();		
		$this->load->model('app_model');
		$this->load->model('search_model');
		$this->load->model('Users_model');
        $this->load->helper('url');
	}
	 
	function home()
	{
		$data["admin_konfirmasi"] = $this->app_model->getWhere("data_penelitian", "status_penelitian", "Menunggu Konfirmasi");
		$data["admin_bahan_limit"] = $this->app_model->getWhereSmaller("bahan", "stok_bahan", 10);
		$data["admin_alat_rusak"] = $this->app_model->getWhere("alat", "status_alat", "Rusak");
		$this->load->view('v_admin_home', $data);
	}
	
	/*public function penelitian(){
		$data["admin_proposal"] = $this->app_model->getNoSort("proposal_peneliti");
		$this->load->view('v_admin_penelitian',$data);

	}*/
	
	function alat(){
		$data["admin_alat"] = $this->app_model->getSorted("alat", "nama_alat");
		$this->load->view('v_admin_alat',$data);
	}
	
	function bahan(){
		$data["admin_bahan"] = $this->app_model->getSorted("bahan", "nama_bahan");
		$this->load->view('v_admin_bahan',$data);	
	}
	
	function transaksi(){
		$data["admin_bahan"] = $this->app_model->getSorted("bahan", "nama_bahan");
		$data["admin_transaksi"] = $this->Users_model->tampil_transaksiAdmin();
		$this->load->view('v_admin_transaksi',$data);	
	}
	
	function daftar_penelitian(){
		$data["admin_penelitian"] = $this->Users_model->tampil_daftarPenelitianAdmin();
		$this->load->view('v_admin_daftar',$data);	
	}
	
	function jadwal(){
		$data["admin_jadwal"] = $this->app_model->getNoSort("jadwal");
		$this->load->view('v_admin_jadwal',$data);
	}
	
	function jadwal_penelitian(){
		$data["admin_jadwal_penelitian"] = $this->Users_model->tampil_jadwalPenelitianAdmin();
		$this->load->view('v_admin_jadwal_penelitian',$data);
	}
	
	function akun_peneliti(){
		$data["admin_akun_peneliti"] = $this->app_model->getNoSort("akun_peneliti");
		$this->load->view('v_admin_akun', $data);
	}
	
	function faq_pengunjung(){
		$data["admin_faq_pengunjung"] = $this->app_model->getWhere("info", "id_info", 1);
		$this->load->view('v_admin_faq_pengunjung', $data);
	}
	
	function faq_peneliti(){
		$data["admin_faq_peneliti"] = $this->app_model->getWhere("info", "id_info", 2);
		$this->load->view('v_admin_faq_peneliti', $data);
	}
	
	function profil_lab(){
		$data["admin_profil_lab"] = $this->app_model->getWhere("info", "id_info", 3);
		$this->load->view('v_admin_profil', $data);
	}
	
	function pengaturan(){
		$data["admin_pengaturan"] = $this->app_model->getNoSort("akun_admin");
		$this->load->view('v_admin_pengaturan', $data);
	}
	
	
}
?>
