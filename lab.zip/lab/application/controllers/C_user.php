<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_user extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other  methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 
	 function __construct(){
		parent::__construct();		
		$this->load->model('app_model');
		$this->load->model('Users_model');
        $this->load->helper('url');
		$this->load->helper('date');
		date_default_timezone_set('Asia/Jakarta');
    
	}
	 
	function home()
	{
		$this->load->view('v_user_home');
	}
	
	function daftar_penelitian(){
		$nim = $this->session->userdata('ses_id');
		$data ["peneliti_penelitian"] = $this->app_model->getWhere("data_penelitian","id_peneliti",$nim);
		$this->load->view('v_user_daftar_penelitian',$data);

	}
	
	function jadwal_peneliti(){
		$nim = $this->session->userdata('ses_id');
		$status= "Aktif";
	//	$data["peneliti_jadwal"] = $this->Users_model->tampil_jadwalPeneliti($nim);
		$data["peneliti_judul"] = $this->Users_model->data_aktif($nim, $status);
	 	$data["peneliti_jadwal"] = $this->app_model->getWhere("jadwal_penelitian","id_peneliti",$nim);
		
		$this->load->view('v_user_jadwal_peneliti',$data);
	}
	
	 function setting(){
		$nim = $this->session->userdata('ses_id');
		$data["akun_peneliti"] = $this->app_model->getWhere("akun_peneliti", "nim_peneliti", $nim);
		$this->load->view('v_user_pengaturan', $data);
	}
	
	function faq_peneliti (){
		$data["akun_faq"] = $this->app_model->getWhere("info", "id_info", 2);
		$this->load->view('v_user_faq', $data);
	}
}
?>