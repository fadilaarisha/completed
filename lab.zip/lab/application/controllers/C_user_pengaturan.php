<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class C_user_pengaturan extends CI_Controller {

    function __construct() {
		parent::__construct();		
		$this->load->model('app_model');
		$this->load->model('Users_model');
        $this->load->helper('url');
		$this->load->helper('date');
		
    //    parent::__construct();
    date_default_timezone_set('Asia/Jakarta');
    //    if ($this->session->logged_in == FALSE) {
			// redirect them to the login page
	//		redirect('auth/logout', 'refresh');
	//	} else {
            /* load the models */
                        
    //    }
    }
	function index(){
        $this->load->view('v_user_pengaturan');
    }
	
	function edit (){
		$pass_lama = $this->input->post('pass_lama');
		$pass_baru = $this->input->post('pass_baru');
		$nim = $this->session->userdata('ses_id');
		$pass_fix = $this->Users_model->auth_password ($nim, $pass_lama);
		
		if ($pass_fix = TRUE){
			$data_edit = array(
				'pass_peneliti' => $pass_baru);					
			$this->app_model->updateData("akun_peneliti", "nim_peneliti", $nim, $data_edit);
		   
			redirect('c_user/home');
			}
		
		else{
			redirect('c_user/pengaturan_akun');
		}
	
} 
}
?>