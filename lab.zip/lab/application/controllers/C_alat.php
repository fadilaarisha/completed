<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class C_alat extends CI_Controller {

    public function __construct() {
		parent::__construct();		
		$this->load->model('app_model');
        $this->load->helper('url');
		$this->load->model('search_model');
		$this->load->library('pdf');
		
    //    parent::__construct();
    //  date_default_timezone_set('Asia/Jakarta');
    //    if ($this->session->logged_in == FALSE) {
			// redirect them to the login page
	//		redirect('auth/logout', 'refresh');
	//	} else {
            /* load the models */
                        
    //    }
    }
	
	function add(){
		$nama_alat_add = $this->input->post('nama_alat_add');
		$jml_alat_add = $this->input->post('jml_alat_add');
		$fungsi_alat_add = $this->input->post('fungsi_alat_add');
		$status_alat_add = $this->input->post('status_alat_add');
		
	  $data_register = array(
        	'nama_alat' => $nama_alat_add,
        	'jml_alat'=>$jml_alat_add,
        	'fungsi_alat'=>$fungsi_alat_add,
			'status_alat'=>$status_alat_add);
			
        $this->app_model->addData("alat", $data_register);    
		redirect('c_admin/alat'); 
	}
	
	function edit ($id){
		$nama_alat_edit = $this->input->post('nama_alat_edit');
		$jml_alat_edit = $this->input->post('jml_alat_edit');
		$fungsi_alat_edit = $this->input->post('fungsi_alat_edit');
		$status_alat_edit = $this->input->post('status_alat_edit');
		
		$data_edit = array(
        	'nama_alat' => $nama_alat_edit,
        	'jml_alat'=>$jml_alat_edit,
        	'fungsi_alat'=>$fungsi_alat_edit,
			'status_alat'=>$status_alat_edit);
		
		$this->app_model->updateData("alat", "id_alat", $id, $data_edit);
		redirect('c_admin/alat');
	}
	
	
	
	function hapus($id){
		$this->app_model->hapus("alat","id_alat", $id);
		/* $this->session->set_flashdata('item','<div class="alert alert-info" role="alert">Data Berhasil Di Hapus</div>'); */
		redirect('c_admin/alat'); 
	}

	function cari(){
		$cari_add = $this->input->post('cari_add');
		$data["hasil_cari"] = $this->search_model->getCariAlat($cari_add);
		$this->load->view('v_admin_hasil_alat',$data);	
	}
	
	function download(){
        $pdf = new FPDF('p','mm','A4');
        // membuat halaman baru
        $pdf->AddPage();
        // setting jenis font yang akan digunakan
        $pdf->SetFont('Arial','B',16);
        // mencetak string 
        $pdf->Cell(190,7,'LABORATORIUM MIKROBIOLOGI',0,1,'C');
        $pdf->SetFont('Arial','B',16);
        $pdf->Cell(190,7,'FAKULTAS TEKNOLOGI PERTANIAN',0,1,'C');
		$pdf->SetFont('Arial','B',16);
        $pdf->Cell(190,7,'UNIVERSITAS ANDALAS',0,1,'C');
		
		$pdf->Cell(190,7,'',0,1);
		$pdf->SetFont('Arial','B',16);
        $pdf->Cell(190,7,'REKAPAN ALAT LABORATORIUM',0,1,'C');
        
		// Memberikan space kebawah agar tidak terlalu rapat
        $pdf->Cell(10,7,'',0,1);
        $pdf->SetFont('Arial','B',10);
        $pdf->Cell(100,6,'Nama Alat',1,0);
        $pdf->Cell(25,6,'Jumlah Alat',1,0, 'C');
		$pdf->Cell(50,6,'Fungsi Alat',1,0, 'C');
        $pdf->Cell(15,6,'Status',1,1, 'C');
        $pdf->SetFont('Arial','',12);
        $bahan = $this->app_model->getSorted('alat', 'nama_alat')->result();
        foreach ($bahan as $row){
            $pdf->Cell(100,6,$row->nama_alat,1,0);
            $pdf->Cell(25,6,$row->jml_alat,1,0, 'C');
			$pdf->Cell(50,6,$row->fungsi_alat,1,0, 'C');
            $pdf->Cell(15,6,$row->status_alat,1,1, 'C');
        }
		$pdf->Cell(10,7,'',0,1);
		$pdf->SetFont('Arial','I',10);
        $pdf->Cell(190,7,'Diunduh pada '. date("l, d-m-Y"),0,1,'C');
        $pdf->Output();
    }

			}
			
	?>	