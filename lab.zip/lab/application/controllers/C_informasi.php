<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class C_informasi extends CI_Controller {

    public function __construct() {
		parent::__construct();		
		$this->load->model('app_model');
                $this->load->helper('url');
		
    //    parent::__construct();
    //  date_default_timezone_set('Asia/Jakarta');
    //    if ($this->session->logged_in == FALSE) {
			// redirect them to the login page
	//		redirect('auth/logout', 'refresh');
	//	} else {
            /* load the models */
                        
    //    }
    }
	
	public function edit ($id){
		$judul_edit = $this->input->post('judul_edit');
		$konten_edit = $this->input->post('konten_edit');
		
		$data_edit = array(
        	'judul_info' => $judul_edit,
        	'konten_info'=>$konten_edit);
		
		$this->app_model->updateData("info", "id_info", $id, $data_edit);
		redirect('c_admin/home');
	}
}		
?>		