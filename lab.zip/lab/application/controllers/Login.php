<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	public function __construct(){
			parent::__construct();
			$this->load->model('Users_model');
			}
	
	 function index(){
        $this->load->view('v_masuk');
    }
	
	function masuk(){
			$id_masuk = $this->input->post('id_masuk');
			$pass_masuk = $this->input->post('pass_masuk');
			$cek_admin = $this->Users_model->auth_admin($id_masuk,$pass_masuk);
			
			if ($cek_admin->num_rows() > 0){
				$data=$cek_admin->row_array();
				$this->session->set_userdata('masuk', TRUE);				
				$this->session->set_userdata('ses_id', $data['id_admin']);
				$this->session->set_userdata('ses_nama', $data['nama_admin']);
				redirect(site_url('c_admin/home'));
				}
			else {
				$cek_peneliti= $this->Users_model->auth_peneliti($id_masuk,$pass_masuk);
				if ($cek_peneliti->num_rows() > 0){
					$data=$cek_peneliti->row_array();
					$this->session->set_userdata('masuk', TRUE);				
					$this->session->set_userdata('ses_id', $data['nim_peneliti']);
					$this->session->set_userdata('ses_nama', $data['nama_peneliti']);
					redirect(site_url('c_user/home'));
				}
				else{
					/* echo $this->session->set_flashdata('msg','Username Atau Password Salah'); */
                    redirect(site_url('Login'));
				}
			}	
	}	
	
	public function logout(){
		$this->session->sess_destroy();
		redirect(site_url('welcome'));
	}
}
?>
