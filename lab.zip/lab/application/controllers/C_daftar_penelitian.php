<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class C_daftar_penelitian extends CI_Controller {

    function __construct() {
		parent::__construct();		
		$this->load->model('app_model');
		$this->load->model('Users_model');
        //$this->load->helper('url');
		$this->load->helper('url');
		
		
    //    parent::__construct();
    //  date_default_timezone_set('Asia/Jakarta');
    //    if ($this->session->logged_in == FALSE) {
			// redirect them to the login page
	//		redirect('auth/logout', 'refresh');
	//	} else {
            /* load the models */
                        
    //    }
    }
	
	function add(){
		$judul_penelitian_add = $this->input->post('judul_penelitian_add');
		$tanggal_mulai_add = $this->input->post('tanggal_mulai_add');
		$tanggal_selesai_add = $this->input->post('tanggal_selesai_add');
		$dosen1_add = $this->input->post('dosen1_add');
		$dosen2_add = $this->input->post('dosen2_add');
		$parameter_add = $this->input->post('parameter_add');
		$status_add = $this->input->post('status_add');
		$catatan_add = $this->input->post('catatan_add');
		$nim_add = $this->input->post('nim_add');
		$nim = $this->session->userdata('ses_id');
		$id_penelitian_add = $this->Users_model->kode_penelitian();
		
		
		
		$cek_nim = $this->app_model->cek_data('akun_peneliti', 'nim_peneliti', $nim);
		
		if ($cek_nim == TRUE){		
			$data_register = array(
				'id_proposal' => $id_penelitian_add,
				'id_peneliti' => $nim,
				'judul_penelitian' => $judul_penelitian_add,
				'mulai_penelitian' => $tanggal_mulai_add,
				'akhir_penelitian' => $tanggal_selesai_add,
				'dosen1_penelitian' => $dosen1_add,
				'dosen2_penelitian' => $dosen2_add,
				'parameter_penelitian' => $parameter_add);

			$this->app_model->addData('data_penelitian', $data_register);		
			redirect('c_user/daftar_penelitian'); }
			
		else {
			$data_register= array (
				'id_proposal' => $id_penelitian_add,
				'id_peneliti' => $nim_add,
				'judul_penelitian' => $judul_penelitian_add,
				'mulai_penelitian' => $tanggal_mulai_add,
				'akhir_penelitian' => $tanggal_selesai_add,
				'dosen1_penelitian' => $dosen1_add,
				'dosen2_penelitian' => $dosen2_add,
				'parameter_penelitian' => $parameter_add,
				'status_penelitian' => $status_add,
				'catatan_penelitian' => $catatan_add);
				
			$this->app_model->addData('data_penelitian', $data_register);		
			redirect('c_admin/daftar_penelitian');
		}
	}
		
	public function edit($id){
		$judul_penelitian_edit = $this->input->post('judul_penelitian_edit');
		$tanggal_mulai_edit = $this->input->post('tanggal_mulai_edit');
		$tanggal_selesai_edit = $this->input->post('tanggal_selesai_edit');
		$dosen1_edit = $this->input->post('dosen1_edit');
		$dosen2_edit = $this->input->post('dosen2_edit');
		$parameter_edit = $this->input->post('parameter_edit');
		$status_edit = $this->input->post('status_edit');
		$catatan_edit = $this->input->post('catatan_edit');
		$nim_edit = $this->input->post('nim_edit');

		
	  $data_edit = array(
        	'id_peneliti' => $nim_edit,
			'judul_penelitian' => $judul_penelitian_edit,
			'mulai_penelitian' => $tanggal_mulai_edit,
			'akhir_penelitian' => $tanggal_selesai_edit,
			'dosen1_penelitian' => $dosen1_edit,
			'dosen2_penelitian' => $dosen2_edit,
			'parameter_penelitian' => $parameter_edit,
			'status_penelitian' => $status_edit,
			'catatan_penelitian' => $catatan_edit);
					
        $this->app_model->updateData("data_penelitian", "id_proposal", $id, $data_edit);
        
		redirect('c_admin/daftar_penelitian');
	}
	
	function hapus($id){
	//	$this->session->set_flashdata('item','<div class="alert alert-danger" role="alert">Well done! You successfully read this important alert message.</div>');
		$nim = $this->session->userdata('ses_id');
		
		$judul_penelitian = (string)$this->app_model->getColumnWhere('data_penelitian', 'judul_penelitian', 'id_proposal', $id);
		
		$this->app_model->hapus('jadwal_penelitian','judul_penelitian', $judul_penelitian);	
		$this->app_model->hapus('data_penelitian','id_proposal', $id);
		
		$cek_admin = $this->app_model->cek_data("akun_admin", "id_admin", $nim);
		if ($cek_admin == FALSE){
			redirect('c_user/daftar_penelitian'); }
		else {
			redirect('c_admin/daftar_penelitian');
		}
		
	}
	


			}
			
	?>	