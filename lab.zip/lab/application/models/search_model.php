<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class search_model extends CI_Model {

		function __construct()
	{
	  parent::__construct();
    }
	
	function getCariBahan($value) {
        $this->db->select ('*');
		$this->db->from("bahan");
		$this->db->like("nama_bahan",$value);
		$this->db->or_like("stok_bahan",$value);
		$this->db->or_like("harga_bahan",$value);
		$this->db->or_like("tgl_update",$value);
		$data = $this->db->get();
		return $data;
		}
		
	function getCariAlat($value) {
        $this->db->select ('*');
		$this->db->from("alat");
		$this->db->like("nama_alat",$value);
		$this->db->or_like("jml_alat",$value);
		$this->db->or_like("fungsi_alat",$value);
		$this->db->or_like("status_alat",$value);
		$this->db->or_like("tgl_update",$value);
		$data = $this->db->get();
		return $data;
		}
	
	function getCariAkun($value) {
        $this->db->select ('*');
		$this->db->from("akun_peneliti");
		$this->db->like("nama_peneliti",$value);
		$this->db->or_like("nim_peneliti",$value);
		$this->db->or_like("jurusan_peneliti",$value);
		$this->db->or_like("fakultas_peneliti",$value);
		$this->db->or_like("email_peneliti",$value);
		$this->db->or_like("pass_peneliti",$value);
		$this->db->or_like("nohp_peneliti",$value);
		$this->db->or_like("alamat_peneliti",$value);
		$data = $this->db->get();
		return $data;
		}
		
	
	}	
		
?>		

	