<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class App_model extends CI_Model {

		function __construct()
	{
	  parent::__construct();
    }
	
	function hapus($table, $column, $id){
			$this->db->where($column, $id)->delete($table);
			
		}
    function getSorted($table, $field) {
            return $this->db->order_by($field, 'ASC')->get($table); 
        }
    function getNoSort($table) {
            return $this->db->get($table); 
        }
        
    function getWhere($table, $column, $value) {
            $data = $this->db->where($column, $value)->get($table);
            return $data;
        }
	
	//khusus bahan <=10
	function getWhereSmaller($table, $column, $value) {
            $data = $this->db->where('stok_bahan <=',  $value)->get($table);
            return $data;
        }
     
	 function getColumn ($table, $column){
		$this->db->select($column);
		$this->db->from($table);
	//	$this->db->where($var,$value);
		$data = $this->db->get();
		return $data;
	 }
	 
	 function getValue($tabel, $kolom, $var, $value){
       $this->db->select('*');
		$this->db->where($var,$value);
		$query= $this->db->get($tabel);
		if($query->num_rows() <> 0) {
			$data = $query->row();
			$hasil = $data->$kolom;
            } 
		else {
             $hasil = "-";    
		}
		return $hasil;
	 }
	 
	 function getColumnWhere ($table, $column, $var, $value){
		$this->db->select($column);
		$this->db->from($table);
		$this->db->where($var,$value);
		$data = $this->db->get()->result();
		return $data;
	 }
	 
	 
       function getWhereOrder($table, $column, $value, $order) {
            $data = $this->db->where($column, $value)->order_by($order, 'ASC')->get($table);
            return $data;
        }
        
        function getWhereOrderAsc($table, $column, $value, $order) {
            $data = $this->db->where($column, $value)->order_by($order, 'ASC')->get($table);
            return $data;
        }
        
        function getGroup($table, $group) {
            $data = $this->db->group_by($group)->get($table);
            return $data;
        }
        
        function getWhereGroup($table, $column, $value, $group) {
            $data = $this->db->where($column, $value)->group_by($group)->get($table);
            return $data;
        }
        
        /* add data */
        function addData($table ,$data) {
            return $this->db->insert($table, $data);
        }
        
        /* update data */
        function updateData($table, $column, $column_id, $data) {
            $this->db->where($column, $column_id);
            $this->db->update($table ,$data);
           /*  if($this->db->affected_rows() > 0) {
                return TRUE;
            } else {
                return FALSE;
            } */
        }
        
         /* check if data exists */
       /*  function check_exists($table, $field, $key) {
		    $this->
            $this->db->where($field ,$key);
            $query = $this->db->get($table);
            return $query->num_rows();
        }  */
	
	
	function cek_data($tabel, $kolom, $value){
       $this->db->select('*');
		$this->db->from($tabel);
		$this->db->where($kolom,$value);
		if($this->db->affected_rows() > 0) {
                return TRUE;
            } else {
                return FALSE;
            }
	}
    
         /* update table with composite key */
        /* function cekData($table, $column1, $column2, $column_id1, $column_id2, $data) {
            $this->db->where($column1, $column_id1, $column2, $column_id2);
            $this->db->update($table ,$data);
            if($this->db->affected_rows() > 0) {
                return TRUE;
            } else {
                return FALSE;
            }
        } */
	}	
		
?>		

	