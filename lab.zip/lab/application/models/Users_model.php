<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users_model extends CI_Model {

//cek nip dan password admin
    function auth_admin($id,$password){
        $query=$this->db->query("SELECT * FROM akun_admin WHERE id_admin='$id' AND pass_admin='$password' LIMIT 1");
        return $query;
    }
	
//cek nim dan password mahasiswa
    function auth_peneliti($nim,$password){
        $query=$this->db->query("SELECT * FROM akun_peneliti WHERE nim_peneliti='$nim' AND pass_peneliti='$password' LIMIT 1");
        return $query;
    }
 
	function tampil_jadwalPeneliti($id)
	{
		$this->db->select('*');
		$this->db->from('jadwal_penelitian');
		$this->db->join('data_penelitian','jadwal_penelitian.id_penelitian = data_penelitian.id_proposal');
		$this->db->where('jadwal_penelitian.id_peneliti', $id);
		$this->db->order_by('tgl_penelitian', 'asc');
		$query = $this->db->get();
		return $query;
		}
		
	function tampil_daftarPenelitianAdmin()
	{
		$this->db->select('*');
		$this->db->from('data_penelitian');
		$this->db->join('akun_peneliti','data_penelitian.id_peneliti= akun_peneliti.nim_peneliti');
	//	$this->db->where('jadwal_penelitian.id_peneliti', $id);
	//	$this->db->order_by('no_antrian', 'asc');
		$query = $this->db->get();
		return $query;
		}
		
	function tampil_transaksiAdmin()
	{
		$this->db->select('*');
		$this->db->from('transaksi');
		$this->db->join('bahan','transaksi.id_bahan= bahan.id_bahan');
		$query = $this->db->get();
		return $query;
		}
		
	function tampil_jadwalPenelitianAdmin()
	{
		$this->db->select('*');
		$this->db->from('jadwal_penelitian');
		$this->db->join('data_penelitian','jadwal_penelitian.judul_penelitian = data_penelitian.judul_penelitian');
		$this->db->join('akun_peneliti','jadwal_penelitian.id_peneliti = akun_peneliti.nim_peneliti');
		$this->db->order_by('tgl_penelitian', 'asc');
	//	$this->db->where('jadwal_penelitian.id_peneliti', $id);
	//	$this->db->order_by('no_antrian', 'asc');
		$query = $this->db->get();
		return $query;
		}
	
	function kode_penelitian(){

		  $this->db->select('RIGHT(data_penelitian.id_proposal,4) as kode', FALSE);
		  $this->db->order_by('id_proposal','DESC');    
		  $this->db->limit(1);    
		  $query = $this->db->get('data_penelitian');      //cek dulu apakah ada sudah ada kode di tabel.    
		  if($query->num_rows() <> 0){      
		   //jika kode ternyata sudah ada.      
		   $data = $query->row();      
		   $kode = intval($data->kode) + 1;    
		  }
		  else {      
		   //jika kode belum ada      
		   $kode = 1;    
		  }

		  $kodemax = str_pad($kode, 4, "0", STR_PAD_LEFT); // angka 4 menunjukkan jumlah digit angka 0
		  $kodejadi = "DP".$kodemax;    // hasilnya ODJ-9921-0001 dst.
		  return $kodejadi;  
	}
	
	function kode_bahan(){

		  $this->db->select('RIGHT(bahan.id_bahan,4) as kode', FALSE);
		  $this->db->order_by('id_bahan','DESC');    
		  $this->db->limit(1);    
		  $query = $this->db->get('bahan');      //cek dulu apakah ada sudah ada kode di tabel.    
		  if($query->num_rows() <> 0){      
		   //jika kode ternyata sudah ada.      
		   $data = $query->row();      
		   $kode = intval($data->kode) + 1;    
		  }
		  else {      
		   //jika kode belum ada      
		   $kode = 1;    
		  }

		  $kodemax = str_pad($kode, 4, "0", STR_PAD_LEFT); // angka 4 menunjukkan jumlah digit angka 0
		  $kodejadi = "BHN".$kodemax;    // hasilnya ODJ-9921-0001 dst.
		  return $kodejadi;  
	}
	
	function data_aktif($nim, $status) {
        $query=$this->db->query("SELECT * FROM data_penelitian WHERE id_peneliti='$nim' AND status_penelitian='$status'");
        return $query;
        }
		
	function data_aktif_admin($nim, $proposal, $status) {
        $query=$this->db->query("SELECT * FROM data_penelitian WHERE id_peneliti='$nim' AND judul_penelitian='$proposal' AND status_penelitian='$status'");
        return TRUE;
        }
	
	 function auth_password($nim,$password){
        $query=$this->db->query("SELECT * FROM akun_peneliti WHERE nim_peneliti='$nim' AND pass_peneliti='$password' LIMIT 1");
        return TRUE;
    }
}
?>