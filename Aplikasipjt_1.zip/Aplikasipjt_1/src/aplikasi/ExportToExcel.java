/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package aplikasi;

import java.io.File;
import java.io.FileWriter;
import javax.swing.JTable;
import javax.swing.table.TableModel;

/**
 *
 * @author Windows 8
 */
public class ExportToExcel {

  
  JTable tabel1;
  File file= new File ("DataTable.xls");

    ExportToExcel(JTable table) {
        tabel1=table;
        ExportTableToExcel(tabel1, file);
    }

    private void ExportTableToExcel(JTable tabel, File file) {
        try{
            
            
            TableModel tableModel = tabel.getModel();
            FileWriter fOut = new FileWriter(file);
            
            for(int i = 0; i < tableModel.getColumnCount(); i++){
                fOut.write(tableModel.getColumnName(i)+"\t");
            }
            
            fOut.write("\n");
            
            for(int i = 0; i < tableModel.getRowCount(); i++){
                for(int j = 0; j < tableModel.getColumnCount(); j++){
                    fOut.write(tableModel.getValueAt(i, j).toString()+"\t");
                }
                fOut.write("\n");
            }
            fOut.close();
        } catch (Exception e){
            e.printStackTrace();
        }

    }  
}
