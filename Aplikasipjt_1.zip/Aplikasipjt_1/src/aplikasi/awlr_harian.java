/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package aplikasi;

import java.io.File;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;

import javax.swing.JOptionPane;
import javax.swing.filechooser.FileFilter;
import javax.swing.table.DefaultTableModel;

public class awlr_harian extends javax.swing.JFrame {

    public String StationName;
    public String StationType;
    public String StationRange;
    private String fileName;

    public awlr_harian(String strStation, String strTypeStation, String strRangeStation) {
        if (strStation == "") {
            this.StationName = "Gadang";
        } else {
            this.StationName = strStation;
        }
        initComponents();
        this.setTable();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        logo = new javax.swing.JLabel();
        judul = new javax.swing.JLabel();
        judul1 = new javax.swing.JLabel();
        btnExport = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new java.awt.GridLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(800, 500));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6", "Title 7", "Title 8", "Title 9", "Title 10"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        logo.setIcon(new javax.swing.ImageIcon("D:\\Kuliah\\7\\KKN\\Aplikasipjt\\res\\JASA TIRTA logo 1.png")); // NOI18N

        judul.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        judul.setText("LAPORAN DATA HIDROLIK PERUM JASA TIRTA I");

        judul1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        judul1.setText("TITTLE");

        btnExport.setText("export to excel");
        btnExport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExportActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 705, Short.MAX_VALUE)
                        .addGap(24, 24, 24))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(judul))
                            .addComponent(judul1, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap())))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnExport)
                .addGap(75, 75, 75))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(judul)))
                .addGap(11, 11, 11)
                .addComponent(judul1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 203, Short.MAX_VALUE)
                .addGap(28, 28, 28)
                .addComponent(btnExport)
                .addGap(19, 19, 19))
        );

        getContentPane().add(jPanel1);

        setSize(new java.awt.Dimension(755, 450));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnExportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExportActionPerformed
        new ExportToExcel(jTable1);
    }//GEN-LAST:event_btnExportActionPerformed
    private File getSelectedFile(final String type) {
        String name = fileName;

        JFileChooser pathChooser = new JFileChooser();
        pathChooser.setFileFilter(new FileFilter() {
            @Override
            public boolean accept(File f) {
                if (f.isDirectory()) {
                    return true;
                } else {
                    if (f.getName().toLowerCase().endsWith(type)) {
                        return true;
                    } else {
                        return false;
                    }
                }
            }

            public String getDescription() {
                return " File format (  " + type + " ）  ";
            }
        });
        pathChooser.setSelectedFile(new File(name + type));
        int showSaveDialog = pathChooser.showSaveDialog(this);
        if (showSaveDialog == JFileChooser.APPROVE_OPTION) {
            return pathChooser.getSelectedFile();
        } else {
            return null;
        }
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(awlr_harian.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(awlr_harian.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(awlr_harian.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(awlr_harian.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new awlr_harian("", "AWLR", "").setVisible(true);
            }
        });
    }

    void setTable() {
        main_menu main3 = new main_menu();
        koneksi conect = new koneksi();// objek koneksi untuk koneksi ke DATABASE (DB)
        ResultSet data = null; //
        int jumBaris = 0; // variable untuk menentukan jumlah baris matriks nantinya
        //query gadang dan lahor harian yang akan ditampilkan, misalkan kita ingin menampilkan data AWLR gadang bulanan dari DB ke table
        String query_gadang = "select date_format(datetime, '%d - %m - %Y') as DATE,max(tma) as MAX_TMA, min(tma) as MIN_TMA, round (avg(tma), 2) as AVG_TMA, level, round (max(discharge), 2) as MAX_DISCHARGE, round (min(discharge), 2) as MIN_DISCHARGE, round (avg(discharge), 2) as AVG_DISCHARGE from awlr_gadang group by day(datetime)ORDER BY id ASC;";
        String query_lahor = "select date_format(datetime, '%d - %m - %Y') as DATE, max(tma) as MAX_TMA, min(tma) as MIN_TMA, round (avg(tma), 2) as AVG_TMA, level, max(discharge) as MAX_DISCHARGE, min(discharge) as MIN_DISCHARGE, avg(discharge) as AVG_DISCHARGE from awlr_lahor group by day(datetime) ORDER BY id ASC;";


        try {
            if (this.StationType == "AWLR") {
                judul1.setText("Stasiun AWLR " + this.StationName + " " + this.StationRange);
            }
            if ("Gadang".equals(this.StationName)) {
                data = conect.getStatement().executeQuery(query_gadang);
            } else if ("Lahor".equals(this.StationName)) {
                data = conect.getStatement().executeQuery(query_lahor);
            }
            while (data.next()) {
                jumBaris++;
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error pada jumlah baris :      " + ex.getMessage());
        }
        //jika jumlah baris telah didapatkan maka buat array 2 dimensi untuk menyimpan data sementara
        String isi[][] = new String[jumBaris][10]; //jumBaris = 10 {Title 1 sampai 10}
        // masukkan data dari ResultStatement kedalam matriks
        int i = 0;//just for loop
        try {
            if ("Gadang".equals(this.StationName)) {
                data = conect.getStatement().executeQuery(query_gadang);
            } // query_gadang dijalankan
            else if ("Lahor".equals(this.StationName)) {
                data = conect.getStatement().executeQuery(query_lahor);
            }


            while (data.next()) {
                isi[i][0] = "" + data.getString("DATE");
                isi[i][1] = "" + data.getString("MAX_TMA");
                isi[i][2] = "" + data.getString("MIN_TMA");
                isi[i][3] = "" + data.getString("AVG_TMA");
                isi[i][4] = "" + data.getString("level");
                isi[i][5] = "" + data.getString("MAX_DISCHARGE");
                isi[i][6] = "" + data.getString("MIN_DISCHARGE");
                isi[i][7] = "" + data.getString("AVG_DISCHARGE");

                i++;
            }
            //data.close();

        } catch (SQLException ex) {
            Logger.getLogger(main_menu.class.getName()).log(Level.SEVERE, null, ex);
        }
        String NamaKolom[] = {"Date", "Max TMA", "Min TMA", "Avg TMA", "Level", "Max Discharge", "Min Discharge", "Avg Discharge"};//nama kolom yang nantinya akan ada pada tabel

        DefaultTableModel model = new DefaultTableModel(isi, NamaKolom) {
        };
        //selanjutnya adalah mlakukan pengesetan pada tabel
        jTable1.setModel(model);
        //done!!!
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnExport;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel judul;
    private javax.swing.JLabel judul1;
    private javax.swing.JLabel logo;
    // End of variables declaration//GEN-END:variables
}
